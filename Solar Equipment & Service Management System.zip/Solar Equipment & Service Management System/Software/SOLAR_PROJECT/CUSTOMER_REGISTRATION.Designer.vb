﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER_REGISTRATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNSEARCH = New System.Windows.Forms.Button
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.LBLCID = New System.Windows.Forms.Label
        Me.LBLCREG = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.LBLFEMALE = New System.Windows.Forms.RadioButton
        Me.LBLMALE = New System.Windows.Forms.RadioButton
        Me.LBLGENDER = New System.Windows.Forms.Label
        Me.LBLEMAIL = New System.Windows.Forms.Label
        Me.LBLCPHNO = New System.Windows.Forms.Label
        Me.LBLCMNO = New System.Windows.Forms.Label
        Me.LBLCADDR = New System.Windows.Forms.Label
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNSEARCH
        '
        Me.BTNSEARCH.Location = New System.Drawing.Point(613, 486)
        Me.BTNSEARCH.Name = "BTNSEARCH"
        Me.BTNSEARCH.Size = New System.Drawing.Size(75, 23)
        Me.BTNSEARCH.TabIndex = 78
        Me.BTNSEARCH.Text = "SEARCH"
        Me.BTNSEARCH.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(773, 486)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 77
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(442, 486)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 76
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(268, 486)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 75
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(87, 486)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 74
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(208, 155)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(219, 20)
        Me.TXTID.TabIndex = 73
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(76, 162)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 72
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'LBLCREG
        '
        Me.LBLCREG.AutoSize = True
        Me.LBLCREG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLCREG.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLCREG.Location = New System.Drawing.Point(140, 55)
        Me.LBLCREG.Name = "LBLCREG"
        Me.LBLCREG.Size = New System.Drawing.Size(626, 56)
        Me.LBLCREG.TabIndex = 71
        Me.LBLCREG.Text = "CUSTOMER REGISTRATION"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(208, 350)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(219, 20)
        Me.TextBox9.TabIndex = 70
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(208, 400)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(219, 20)
        Me.TextBox8.TabIndex = 69
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(637, 350)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(219, 20)
        Me.TextBox7.TabIndex = 68
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(208, 255)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(219, 70)
        Me.TextBox2.TabIndex = 67
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(208, 208)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(219, 20)
        Me.TextBox1.TabIndex = 66
        '
        'LBLFEMALE
        '
        Me.LBLFEMALE.AutoSize = True
        Me.LBLFEMALE.Location = New System.Drawing.Point(360, 438)
        Me.LBLFEMALE.Name = "LBLFEMALE"
        Me.LBLFEMALE.Size = New System.Drawing.Size(67, 17)
        Me.LBLFEMALE.TabIndex = 65
        Me.LBLFEMALE.TabStop = True
        Me.LBLFEMALE.Text = "FEMALE"
        Me.LBLFEMALE.UseVisualStyleBackColor = True
        '
        'LBLMALE
        '
        Me.LBLMALE.AutoSize = True
        Me.LBLMALE.Location = New System.Drawing.Point(208, 438)
        Me.LBLMALE.Name = "LBLMALE"
        Me.LBLMALE.Size = New System.Drawing.Size(54, 17)
        Me.LBLMALE.TabIndex = 64
        Me.LBLMALE.TabStop = True
        Me.LBLMALE.Text = "MALE"
        Me.LBLMALE.UseVisualStyleBackColor = True
        '
        'LBLGENDER
        '
        Me.LBLGENDER.AutoSize = True
        Me.LBLGENDER.Location = New System.Drawing.Point(76, 443)
        Me.LBLGENDER.Name = "LBLGENDER"
        Me.LBLGENDER.Size = New System.Drawing.Size(53, 13)
        Me.LBLGENDER.TabIndex = 63
        Me.LBLGENDER.Text = "GENDER"
        '
        'LBLEMAIL
        '
        Me.LBLEMAIL.AutoSize = True
        Me.LBLEMAIL.Location = New System.Drawing.Point(76, 403)
        Me.LBLEMAIL.Name = "LBLEMAIL"
        Me.LBLEMAIL.Size = New System.Drawing.Size(53, 13)
        Me.LBLEMAIL.TabIndex = 62
        Me.LBLEMAIL.Text = "EMAIL ID"
        '
        'LBLCPHNO
        '
        Me.LBLCPHNO.AutoSize = True
        Me.LBLCPHNO.Location = New System.Drawing.Point(505, 357)
        Me.LBLCPHNO.Name = "LBLCPHNO"
        Me.LBLCPHNO.Size = New System.Drawing.Size(121, 13)
        Me.LBLCPHNO.TabIndex = 61
        Me.LBLCPHNO.Text = "ALTERNATE NUMBER"
        '
        'LBLCMNO
        '
        Me.LBLCMNO.AutoSize = True
        Me.LBLCMNO.Location = New System.Drawing.Point(73, 357)
        Me.LBLCMNO.Name = "LBLCMNO"
        Me.LBLCMNO.Size = New System.Drawing.Size(97, 13)
        Me.LBLCMNO.TabIndex = 60
        Me.LBLCMNO.Text = "MOBILE NUMBER"
        '
        'LBLCADDR
        '
        Me.LBLCADDR.AutoSize = True
        Me.LBLCADDR.Location = New System.Drawing.Point(76, 268)
        Me.LBLCADDR.Name = "LBLCADDR"
        Me.LBLCADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLCADDR.TabIndex = 59
        Me.LBLCADDR.Text = "ADDRESS"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(76, 215)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 58
        Me.LBLCNAME.Text = "NAME"
        '
        'CUSTOMER_REGISTRATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(875, 521)
        Me.Controls.Add(Me.BTNSEARCH)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.TXTID)
        Me.Controls.Add(Me.LBLCID)
        Me.Controls.Add(Me.LBLCREG)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LBLFEMALE)
        Me.Controls.Add(Me.LBLMALE)
        Me.Controls.Add(Me.LBLGENDER)
        Me.Controls.Add(Me.LBLEMAIL)
        Me.Controls.Add(Me.LBLCPHNO)
        Me.Controls.Add(Me.LBLCMNO)
        Me.Controls.Add(Me.LBLCADDR)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Name = "CUSTOMER_REGISTRATION"
        Me.Text = "CUSTOMER REGISTRATION FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNSEARCH As System.Windows.Forms.Button
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents LBLCREG As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents LBLFEMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLGENDER As System.Windows.Forms.Label
    Friend WithEvents LBLEMAIL As System.Windows.Forms.Label
    Friend WithEvents LBLCPHNO As System.Windows.Forms.Label
    Friend WithEvents LBLCMNO As System.Windows.Forms.Label
    Friend WithEvents LBLCADDR As System.Windows.Forms.Label
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
End Class
