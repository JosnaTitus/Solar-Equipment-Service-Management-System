﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER_ORDER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLCORDER = New System.Windows.Forms.Label
        Me.CMBCNAME = New System.Windows.Forms.ComboBox
        Me.TXTCID = New System.Windows.Forms.TextBox
        Me.TXTOID = New System.Windows.Forms.TextBox
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.LBLCID = New System.Windows.Forms.Label
        Me.LBLOID = New System.Windows.Forms.Label
        Me.GRPCDETAIL = New System.Windows.Forms.GroupBox
        Me.TXTDATE = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RADPV = New System.Windows.Forms.RadioButton
        Me.RADTHERMAL = New System.Windows.Forms.RadioButton
        Me.GRPODETAILS = New System.Windows.Forms.GroupBox
        Me.GRPTOTAL = New System.Windows.Forms.GroupBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.TXTADV = New System.Windows.Forms.TextBox
        Me.TXTBALANCE = New System.Windows.Forms.TextBox
        Me.LBLPV = New System.Windows.Forms.Label
        Me.LBLTTYPE = New System.Windows.Forms.Label
        Me.LBLRATE = New System.Windows.Forms.Label
        Me.LBLTE = New System.Windows.Forms.Label
        Me.LBLADV = New System.Windows.Forms.Label
        Me.LBLBALANCE = New System.Windows.Forms.Label
        Me.LBLQTY = New System.Windows.Forms.Label
        Me.TXTRATE = New System.Windows.Forms.TextBox
        Me.TXTQTY = New System.Windows.Forms.TextBox
        Me.CMBPTYPE = New System.Windows.Forms.ComboBox
        Me.CMBTTYPE = New System.Windows.Forms.ComboBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.BTNCALCULATE = New System.Windows.Forms.Button
        Me.GRPCDETAIL.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GRPODETAILS.SuspendLayout()
        Me.GRPTOTAL.SuspendLayout()
        Me.SuspendLayout()
        '
        'LBLCORDER
        '
        Me.LBLCORDER.AutoSize = True
        Me.LBLCORDER.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLCORDER.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLCORDER.Location = New System.Drawing.Point(124, 9)
        Me.LBLCORDER.Name = "LBLCORDER"
        Me.LBLCORDER.Size = New System.Drawing.Size(648, 56)
        Me.LBLCORDER.TabIndex = 108
        Me.LBLCORDER.Text = "CUSTOMER ORDER DETAILS"
        '
        'CMBCNAME
        '
        Me.CMBCNAME.FormattingEnabled = True
        Me.CMBCNAME.Location = New System.Drawing.Point(177, 82)
        Me.CMBCNAME.Name = "CMBCNAME"
        Me.CMBCNAME.Size = New System.Drawing.Size(163, 21)
        Me.CMBCNAME.TabIndex = 115
        Me.CMBCNAME.Text = "SELECT CUSTOMER NAME"
        '
        'TXTCID
        '
        Me.TXTCID.Location = New System.Drawing.Point(529, 78)
        Me.TXTCID.Name = "TXTCID"
        Me.TXTCID.Size = New System.Drawing.Size(143, 20)
        Me.TXTCID.TabIndex = 114
        '
        'TXTOID
        '
        Me.TXTOID.Location = New System.Drawing.Point(177, 25)
        Me.TXTOID.Name = "TXTOID"
        Me.TXTOID.Size = New System.Drawing.Size(163, 20)
        Me.TXTOID.TabIndex = 113
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(20, 82)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 112
        Me.LBLCNAME.Text = "NAME"
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(398, 28)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLDATE.TabIndex = 111
        Me.LBLDATE.Text = "DATE"
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(398, 85)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 110
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'LBLOID
        '
        Me.LBLOID.AutoSize = True
        Me.LBLOID.Location = New System.Drawing.Point(20, 25)
        Me.LBLOID.Name = "LBLOID"
        Me.LBLOID.Size = New System.Drawing.Size(60, 13)
        Me.LBLOID.TabIndex = 109
        Me.LBLOID.Text = "ORDER ID"
        '
        'GRPCDETAIL
        '
        Me.GRPCDETAIL.Controls.Add(Me.TXTDATE)
        Me.GRPCDETAIL.Controls.Add(Me.CMBCNAME)
        Me.GRPCDETAIL.Controls.Add(Me.TXTCID)
        Me.GRPCDETAIL.Controls.Add(Me.TXTOID)
        Me.GRPCDETAIL.Controls.Add(Me.LBLCNAME)
        Me.GRPCDETAIL.Controls.Add(Me.LBLDATE)
        Me.GRPCDETAIL.Controls.Add(Me.LBLCID)
        Me.GRPCDETAIL.Controls.Add(Me.LBLOID)
        Me.GRPCDETAIL.Location = New System.Drawing.Point(100, 101)
        Me.GRPCDETAIL.Name = "GRPCDETAIL"
        Me.GRPCDETAIL.Size = New System.Drawing.Size(704, 126)
        Me.GRPCDETAIL.TabIndex = 117
        Me.GRPCDETAIL.TabStop = False
        Me.GRPCDETAIL.Text = "CUSTOMER DETAILS"
        '
        'TXTDATE
        '
        Me.TXTDATE.Location = New System.Drawing.Point(529, 22)
        Me.TXTDATE.Name = "TXTDATE"
        Me.TXTDATE.Size = New System.Drawing.Size(143, 20)
        Me.TXTDATE.TabIndex = 118
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.RADTHERMAL)
        Me.Panel1.Controls.Add(Me.RADPV)
        Me.Panel1.Location = New System.Drawing.Point(104, 246)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(699, 64)
        Me.Panel1.TabIndex = 118
        '
        'RADPV
        '
        Me.RADPV.AutoSize = True
        Me.RADPV.Location = New System.Drawing.Point(20, 28)
        Me.RADPV.Name = "RADPV"
        Me.RADPV.Size = New System.Drawing.Size(101, 17)
        Me.RADPV.TabIndex = 0
        Me.RADPV.TabStop = True
        Me.RADPV.Text = "PHOTOVOLTIC"
        Me.RADPV.UseVisualStyleBackColor = True
        '
        'RADTHERMAL
        '
        Me.RADTHERMAL.AutoSize = True
        Me.RADTHERMAL.Location = New System.Drawing.Point(397, 28)
        Me.RADTHERMAL.Name = "RADTHERMAL"
        Me.RADTHERMAL.Size = New System.Drawing.Size(77, 17)
        Me.RADTHERMAL.TabIndex = 1
        Me.RADTHERMAL.TabStop = True
        Me.RADTHERMAL.Text = "THERMAL"
        Me.RADTHERMAL.UseVisualStyleBackColor = True
        '
        'GRPODETAILS
        '
        Me.GRPODETAILS.Controls.Add(Me.BTNCALCULATE)
        Me.GRPODETAILS.Controls.Add(Me.CMBTTYPE)
        Me.GRPODETAILS.Controls.Add(Me.CMBPTYPE)
        Me.GRPODETAILS.Controls.Add(Me.TXTQTY)
        Me.GRPODETAILS.Controls.Add(Me.TXTRATE)
        Me.GRPODETAILS.Controls.Add(Me.LBLQTY)
        Me.GRPODETAILS.Controls.Add(Me.LBLRATE)
        Me.GRPODETAILS.Controls.Add(Me.LBLTTYPE)
        Me.GRPODETAILS.Controls.Add(Me.LBLPV)
        Me.GRPODETAILS.Location = New System.Drawing.Point(106, 337)
        Me.GRPODETAILS.Name = "GRPODETAILS"
        Me.GRPODETAILS.Size = New System.Drawing.Size(333, 220)
        Me.GRPODETAILS.TabIndex = 119
        Me.GRPODETAILS.TabStop = False
        Me.GRPODETAILS.Text = "ORDER DETAILS"
        '
        'GRPTOTAL
        '
        Me.GRPTOTAL.Controls.Add(Me.LBLBALANCE)
        Me.GRPTOTAL.Controls.Add(Me.LBLADV)
        Me.GRPTOTAL.Controls.Add(Me.LBLTE)
        Me.GRPTOTAL.Controls.Add(Me.TXTBALANCE)
        Me.GRPTOTAL.Controls.Add(Me.TXTADV)
        Me.GRPTOTAL.Controls.Add(Me.TXTTE)
        Me.GRPTOTAL.Location = New System.Drawing.Point(471, 337)
        Me.GRPTOTAL.Name = "GRPTOTAL"
        Me.GRPTOTAL.Size = New System.Drawing.Size(333, 220)
        Me.GRPTOTAL.TabIndex = 120
        Me.GRPTOTAL.TabStop = False
        Me.GRPTOTAL.Text = "TOTAL"
        '
        'TXTTE
        '
        Me.TXTTE.Location = New System.Drawing.Point(142, 34)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(100, 20)
        Me.TXTTE.TabIndex = 0
        '
        'TXTADV
        '
        Me.TXTADV.Location = New System.Drawing.Point(142, 79)
        Me.TXTADV.Name = "TXTADV"
        Me.TXTADV.Size = New System.Drawing.Size(100, 20)
        Me.TXTADV.TabIndex = 1
        Me.TXTADV.Text = "CUSTOMER ORDER FORM"
        '
        'TXTBALANCE
        '
        Me.TXTBALANCE.Location = New System.Drawing.Point(142, 130)
        Me.TXTBALANCE.Name = "TXTBALANCE"
        Me.TXTBALANCE.Size = New System.Drawing.Size(100, 20)
        Me.TXTBALANCE.TabIndex = 2
        '
        'LBLPV
        '
        Me.LBLPV.AutoSize = True
        Me.LBLPV.Location = New System.Drawing.Point(15, 34)
        Me.LBLPV.Name = "LBLPV"
        Me.LBLPV.Size = New System.Drawing.Size(114, 13)
        Me.LBLPV.TabIndex = 0
        Me.LBLPV.Text = "PHOTOVOLTIC TYPE"
        '
        'LBLTTYPE
        '
        Me.LBLTTYPE.AutoSize = True
        Me.LBLTTYPE.Location = New System.Drawing.Point(15, 70)
        Me.LBLTTYPE.Name = "LBLTTYPE"
        Me.LBLTTYPE.Size = New System.Drawing.Size(90, 13)
        Me.LBLTTYPE.TabIndex = 1
        Me.LBLTTYPE.Text = "THERMAL TYPE"
        '
        'LBLRATE
        '
        Me.LBLRATE.AutoSize = True
        Me.LBLRATE.Location = New System.Drawing.Point(15, 105)
        Me.LBLRATE.Name = "LBLRATE"
        Me.LBLRATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLRATE.TabIndex = 2
        Me.LBLRATE.Text = "RATE"
        '
        'LBLTE
        '
        Me.LBLTE.AutoSize = True
        Me.LBLTE.Location = New System.Drawing.Point(6, 41)
        Me.LBLTE.Name = "LBLTE"
        Me.LBLTE.Size = New System.Drawing.Size(95, 13)
        Me.LBLTE.TabIndex = 3
        Me.LBLTE.Text = "TOTAL EXPENSE"
        '
        'LBLADV
        '
        Me.LBLADV.AutoSize = True
        Me.LBLADV.Location = New System.Drawing.Point(6, 86)
        Me.LBLADV.Name = "LBLADV"
        Me.LBLADV.Size = New System.Drawing.Size(58, 13)
        Me.LBLADV.TabIndex = 4
        Me.LBLADV.Text = "ADVANCE"
        '
        'LBLBALANCE
        '
        Me.LBLBALANCE.AutoSize = True
        Me.LBLBALANCE.Location = New System.Drawing.Point(6, 137)
        Me.LBLBALANCE.Name = "LBLBALANCE"
        Me.LBLBALANCE.Size = New System.Drawing.Size(56, 13)
        Me.LBLBALANCE.TabIndex = 5
        Me.LBLBALANCE.Text = "BALANCE"
        '
        'LBLQTY
        '
        Me.LBLQTY.AutoSize = True
        Me.LBLQTY.Location = New System.Drawing.Point(15, 144)
        Me.LBLQTY.Name = "LBLQTY"
        Me.LBLQTY.Size = New System.Drawing.Size(62, 13)
        Me.LBLQTY.TabIndex = 121
        Me.LBLQTY.Text = "QUANTITY"
        '
        'TXTRATE
        '
        Me.TXTRATE.Location = New System.Drawing.Point(171, 98)
        Me.TXTRATE.Name = "TXTRATE"
        Me.TXTRATE.Size = New System.Drawing.Size(121, 20)
        Me.TXTRATE.TabIndex = 122
        '
        'TXTQTY
        '
        Me.TXTQTY.Location = New System.Drawing.Point(171, 137)
        Me.TXTQTY.Name = "TXTQTY"
        Me.TXTQTY.Size = New System.Drawing.Size(121, 20)
        Me.TXTQTY.TabIndex = 125
        '
        'CMBPTYPE
        '
        Me.CMBPTYPE.FormattingEnabled = True
        Me.CMBPTYPE.Location = New System.Drawing.Point(171, 26)
        Me.CMBPTYPE.Name = "CMBPTYPE"
        Me.CMBPTYPE.Size = New System.Drawing.Size(121, 21)
        Me.CMBPTYPE.TabIndex = 126
        Me.CMBPTYPE.Text = "SELECT TYPE"
        '
        'CMBTTYPE
        '
        Me.CMBTTYPE.FormattingEnabled = True
        Me.CMBTTYPE.Location = New System.Drawing.Point(171, 62)
        Me.CMBTTYPE.Name = "CMBTTYPE"
        Me.CMBTTYPE.Size = New System.Drawing.Size(121, 21)
        Me.CMBTTYPE.TabIndex = 127
        Me.CMBTTYPE.Text = "SELECT TYPE"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(660, 575)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 124
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(516, 575)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 123
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(342, 575)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 122
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(161, 575)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 121
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'BTNCALCULATE
        '
        Me.BTNCALCULATE.Location = New System.Drawing.Point(80, 178)
        Me.BTNCALCULATE.Name = "BTNCALCULATE"
        Me.BTNCALCULATE.Size = New System.Drawing.Size(124, 24)
        Me.BTNCALCULATE.TabIndex = 128
        Me.BTNCALCULATE.Text = "CALCULATE"
        Me.BTNCALCULATE.UseVisualStyleBackColor = True
        '
        'CUSTOMER_ORDER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 610)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.GRPTOTAL)
        Me.Controls.Add(Me.GRPODETAILS)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GRPCDETAIL)
        Me.Controls.Add(Me.LBLCORDER)
        Me.Name = "CUSTOMER_ORDER"
        Me.Text = "CUSTOMER_ORDER"
        Me.GRPCDETAIL.ResumeLayout(False)
        Me.GRPCDETAIL.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GRPODETAILS.ResumeLayout(False)
        Me.GRPODETAILS.PerformLayout()
        Me.GRPTOTAL.ResumeLayout(False)
        Me.GRPTOTAL.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLCORDER As System.Windows.Forms.Label
    Friend WithEvents CMBCNAME As System.Windows.Forms.ComboBox
    Friend WithEvents TXTCID As System.Windows.Forms.TextBox
    Friend WithEvents TXTOID As System.Windows.Forms.TextBox
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents LBLOID As System.Windows.Forms.Label
    Friend WithEvents GRPCDETAIL As System.Windows.Forms.GroupBox
    Friend WithEvents TXTDATE As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RADTHERMAL As System.Windows.Forms.RadioButton
    Friend WithEvents RADPV As System.Windows.Forms.RadioButton
    Friend WithEvents GRPODETAILS As System.Windows.Forms.GroupBox
    Friend WithEvents LBLRATE As System.Windows.Forms.Label
    Friend WithEvents LBLTTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLPV As System.Windows.Forms.Label
    Friend WithEvents GRPTOTAL As System.Windows.Forms.GroupBox
    Friend WithEvents LBLBALANCE As System.Windows.Forms.Label
    Friend WithEvents LBLADV As System.Windows.Forms.Label
    Friend WithEvents LBLTE As System.Windows.Forms.Label
    Friend WithEvents TXTBALANCE As System.Windows.Forms.TextBox
    Friend WithEvents TXTADV As System.Windows.Forms.TextBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents LBLQTY As System.Windows.Forms.Label
    Friend WithEvents TXTQTY As System.Windows.Forms.TextBox
    Friend WithEvents TXTRATE As System.Windows.Forms.TextBox
    Friend WithEvents CMBTTYPE As System.Windows.Forms.ComboBox
    Friend WithEvents CMBPTYPE As System.Windows.Forms.ComboBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents BTNCALCULATE As System.Windows.Forms.Button
End Class
