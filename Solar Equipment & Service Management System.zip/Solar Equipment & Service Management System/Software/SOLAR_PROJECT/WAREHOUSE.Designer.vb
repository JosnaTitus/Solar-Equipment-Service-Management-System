﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WAREHOUSE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLCAP = New System.Windows.Forms.Label
        Me.LBLWTYPE = New System.Windows.Forms.Label
        Me.LBLWID = New System.Windows.Forms.Label
        Me.TXTCAP = New System.Windows.Forms.TextBox
        Me.TXTWTYPE = New System.Windows.Forms.TextBox
        Me.TXTWID = New System.Windows.Forms.TextBox
        Me.LBLWAREHOUSE = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LBLCAP
        '
        Me.LBLCAP.AutoSize = True
        Me.LBLCAP.Location = New System.Drawing.Point(294, 308)
        Me.LBLCAP.Name = "LBLCAP"
        Me.LBLCAP.Size = New System.Drawing.Size(59, 13)
        Me.LBLCAP.TabIndex = 133
        Me.LBLCAP.Text = "CAPACITY"
        '
        'LBLWTYPE
        '
        Me.LBLWTYPE.AutoSize = True
        Me.LBLWTYPE.Location = New System.Drawing.Point(294, 227)
        Me.LBLWTYPE.Name = "LBLWTYPE"
        Me.LBLWTYPE.Size = New System.Drawing.Size(109, 13)
        Me.LBLWTYPE.TabIndex = 132
        Me.LBLWTYPE.Text = "WAREHOUSE TYPE"
        '
        'LBLWID
        '
        Me.LBLWID.AutoSize = True
        Me.LBLWID.Location = New System.Drawing.Point(294, 147)
        Me.LBLWID.Name = "LBLWID"
        Me.LBLWID.Size = New System.Drawing.Size(92, 13)
        Me.LBLWID.TabIndex = 131
        Me.LBLWID.Text = "WAREHOUSE ID"
        '
        'TXTCAP
        '
        Me.TXTCAP.Location = New System.Drawing.Point(509, 308)
        Me.TXTCAP.Name = "TXTCAP"
        Me.TXTCAP.Size = New System.Drawing.Size(100, 20)
        Me.TXTCAP.TabIndex = 130
        '
        'TXTWTYPE
        '
        Me.TXTWTYPE.Location = New System.Drawing.Point(509, 220)
        Me.TXTWTYPE.Name = "TXTWTYPE"
        Me.TXTWTYPE.Size = New System.Drawing.Size(100, 20)
        Me.TXTWTYPE.TabIndex = 129
        '
        'TXTWID
        '
        Me.TXTWID.Location = New System.Drawing.Point(509, 140)
        Me.TXTWID.Name = "TXTWID"
        Me.TXTWID.Size = New System.Drawing.Size(100, 20)
        Me.TXTWID.TabIndex = 128
        '
        'LBLWAREHOUSE
        '
        Me.LBLWAREHOUSE.AutoSize = True
        Me.LBLWAREHOUSE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLWAREHOUSE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLWAREHOUSE.Location = New System.Drawing.Point(193, 28)
        Me.LBLWAREHOUSE.Name = "LBLWAREHOUSE"
        Me.LBLWAREHOUSE.Size = New System.Drawing.Size(525, 56)
        Me.LBLWAREHOUSE.TabIndex = 127
        Me.LBLWAREHOUSE.Text = "WAREHOUSE DETAILS"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(643, 398)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 152
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(499, 398)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 151
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(325, 398)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 150
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(144, 398)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 149
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'WAREHOUSE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(892, 551)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLCAP)
        Me.Controls.Add(Me.LBLWTYPE)
        Me.Controls.Add(Me.LBLWID)
        Me.Controls.Add(Me.TXTCAP)
        Me.Controls.Add(Me.TXTWTYPE)
        Me.Controls.Add(Me.TXTWID)
        Me.Controls.Add(Me.LBLWAREHOUSE)
        Me.Name = "WAREHOUSE"
        Me.Text = "WAREHOUSE DETAIL FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLCAP As System.Windows.Forms.Label
    Friend WithEvents LBLWTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLWID As System.Windows.Forms.Label
    Friend WithEvents TXTCAP As System.Windows.Forms.TextBox
    Friend WithEvents TXTWTYPE As System.Windows.Forms.TextBox
    Friend WithEvents TXTWID As System.Windows.Forms.TextBox
    Friend WithEvents LBLWAREHOUSE As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
End Class
