﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IN_OUT_EXPENSE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLVEHICLE = New System.Windows.Forms.Label
        Me.TXTINXOME = New System.Windows.Forms.TextBox
        Me.TXTRESULT = New System.Windows.Forms.TextBox
        Me.TXTEXPENSE = New System.Windows.Forms.TextBox
        Me.LBLINCOME = New System.Windows.Forms.Label
        Me.LBLEXPENSE = New System.Windows.Forms.Label
        Me.BTNREFRESH = New System.Windows.Forms.Button
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LBLVEHICLE
        '
        Me.LBLVEHICLE.AutoSize = True
        Me.LBLVEHICLE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLVEHICLE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLVEHICLE.Location = New System.Drawing.Point(118, 27)
        Me.LBLVEHICLE.Name = "LBLVEHICLE"
        Me.LBLVEHICLE.Size = New System.Drawing.Size(615, 56)
        Me.LBLVEHICLE.TabIndex = 120
        Me.LBLVEHICLE.Text = "IN-OUT EXPENSE DETAILS"
        '
        'TXTINXOME
        '
        Me.TXTINXOME.Location = New System.Drawing.Point(231, 145)
        Me.TXTINXOME.Name = "TXTINXOME"
        Me.TXTINXOME.Size = New System.Drawing.Size(100, 20)
        Me.TXTINXOME.TabIndex = 121
        '
        'TXTRESULT
        '
        Me.TXTRESULT.Location = New System.Drawing.Point(403, 244)
        Me.TXTRESULT.Name = "TXTRESULT"
        Me.TXTRESULT.Size = New System.Drawing.Size(100, 20)
        Me.TXTRESULT.TabIndex = 122
        '
        'TXTEXPENSE
        '
        Me.TXTEXPENSE.Location = New System.Drawing.Point(617, 145)
        Me.TXTEXPENSE.Name = "TXTEXPENSE"
        Me.TXTEXPENSE.Size = New System.Drawing.Size(100, 20)
        Me.TXTEXPENSE.TabIndex = 123
        '
        'LBLINCOME
        '
        Me.LBLINCOME.AutoSize = True
        Me.LBLINCOME.Location = New System.Drawing.Point(103, 152)
        Me.LBLINCOME.Name = "LBLINCOME"
        Me.LBLINCOME.Size = New System.Drawing.Size(87, 13)
        Me.LBLINCOME.TabIndex = 124
        Me.LBLINCOME.Text = "TOTAL INCOME"
        '
        'LBLEXPENSE
        '
        Me.LBLEXPENSE.AutoSize = True
        Me.LBLEXPENSE.Location = New System.Drawing.Point(445, 152)
        Me.LBLEXPENSE.Name = "LBLEXPENSE"
        Me.LBLEXPENSE.Size = New System.Drawing.Size(95, 13)
        Me.LBLEXPENSE.TabIndex = 125
        Me.LBLEXPENSE.Text = "TOTAL EXPENSE"
        '
        'BTNREFRESH
        '
        Me.BTNREFRESH.Location = New System.Drawing.Point(231, 348)
        Me.BTNREFRESH.Name = "BTNREFRESH"
        Me.BTNREFRESH.Size = New System.Drawing.Size(75, 23)
        Me.BTNREFRESH.TabIndex = 126
        Me.BTNREFRESH.Text = "REFRESH"
        Me.BTNREFRESH.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(571, 348)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 127
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'IN_OUT_EXPENSE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 427)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNREFRESH)
        Me.Controls.Add(Me.LBLEXPENSE)
        Me.Controls.Add(Me.LBLINCOME)
        Me.Controls.Add(Me.TXTEXPENSE)
        Me.Controls.Add(Me.TXTRESULT)
        Me.Controls.Add(Me.TXTINXOME)
        Me.Controls.Add(Me.LBLVEHICLE)
        Me.Name = "IN_OUT_EXPENSE"
        Me.Text = "IN-OUT EXPENSE FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLVEHICLE As System.Windows.Forms.Label
    Friend WithEvents TXTINXOME As System.Windows.Forms.TextBox
    Friend WithEvents TXTRESULT As System.Windows.Forms.TextBox
    Friend WithEvents TXTEXPENSE As System.Windows.Forms.TextBox
    Friend WithEvents LBLINCOME As System.Windows.Forms.Label
    Friend WithEvents LBLEXPENSE As System.Windows.Forms.Label
    Friend WithEvents BTNREFRESH As System.Windows.Forms.Button
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
End Class
