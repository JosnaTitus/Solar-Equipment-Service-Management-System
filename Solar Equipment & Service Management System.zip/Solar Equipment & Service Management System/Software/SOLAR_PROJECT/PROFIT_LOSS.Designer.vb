﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PROFIT_LOSS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNREFRESH = New System.Windows.Forms.Button
        Me.LBLLOSS = New System.Windows.Forms.Label
        Me.LBLPROFIT = New System.Windows.Forms.Label
        Me.TXTLOSS = New System.Windows.Forms.TextBox
        Me.TXTPROFIT = New System.Windows.Forms.TextBox
        Me.LBLDETAILS = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(585, 243)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 135
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNREFRESH
        '
        Me.BTNREFRESH.Location = New System.Drawing.Point(253, 243)
        Me.BTNREFRESH.Name = "BTNREFRESH"
        Me.BTNREFRESH.Size = New System.Drawing.Size(75, 23)
        Me.BTNREFRESH.TabIndex = 134
        Me.BTNREFRESH.Text = "REFRESH"
        Me.BTNREFRESH.UseVisualStyleBackColor = True
        '
        'LBLLOSS
        '
        Me.LBLLOSS.AutoSize = True
        Me.LBLLOSS.Location = New System.Drawing.Point(504, 155)
        Me.LBLLOSS.Name = "LBLLOSS"
        Me.LBLLOSS.Size = New System.Drawing.Size(35, 13)
        Me.LBLLOSS.TabIndex = 133
        Me.LBLLOSS.Text = "LOSS"
        '
        'LBLPROFIT
        '
        Me.LBLPROFIT.AutoSize = True
        Me.LBLPROFIT.Location = New System.Drawing.Point(162, 155)
        Me.LBLPROFIT.Name = "LBLPROFIT"
        Me.LBLPROFIT.Size = New System.Drawing.Size(46, 13)
        Me.LBLPROFIT.TabIndex = 132
        Me.LBLPROFIT.Text = "PROFIT"
        '
        'TXTLOSS
        '
        Me.TXTLOSS.Location = New System.Drawing.Point(630, 148)
        Me.TXTLOSS.Name = "TXTLOSS"
        Me.TXTLOSS.Size = New System.Drawing.Size(100, 20)
        Me.TXTLOSS.TabIndex = 131
        '
        'TXTPROFIT
        '
        Me.TXTPROFIT.Location = New System.Drawing.Point(290, 148)
        Me.TXTPROFIT.Name = "TXTPROFIT"
        Me.TXTPROFIT.Size = New System.Drawing.Size(100, 20)
        Me.TXTPROFIT.TabIndex = 129
        '
        'LBLDETAILS
        '
        Me.LBLDETAILS.AutoSize = True
        Me.LBLDETAILS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLDETAILS.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLDETAILS.Location = New System.Drawing.Point(191, 29)
        Me.LBLDETAILS.Name = "LBLDETAILS"
        Me.LBLDETAILS.Size = New System.Drawing.Size(636, 56)
        Me.LBLDETAILS.TabIndex = 128
        Me.LBLDETAILS.Text = "PROFIT AND LOSS DETAILS"
        '
        'PROFIT_LOSS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(892, 402)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNREFRESH)
        Me.Controls.Add(Me.LBLLOSS)
        Me.Controls.Add(Me.LBLPROFIT)
        Me.Controls.Add(Me.TXTLOSS)
        Me.Controls.Add(Me.TXTPROFIT)
        Me.Controls.Add(Me.LBLDETAILS)
        Me.Name = "PROFIT_LOSS"
        Me.Text = "PROFIT & LOSS FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNREFRESH As System.Windows.Forms.Button
    Friend WithEvents LBLLOSS As System.Windows.Forms.Label
    Friend WithEvents LBLPROFIT As System.Windows.Forms.Label
    Friend WithEvents TXTLOSS As System.Windows.Forms.TextBox
    Friend WithEvents TXTPROFIT As System.Windows.Forms.TextBox
    Friend WithEvents LBLDETAILS As System.Windows.Forms.Label
End Class
