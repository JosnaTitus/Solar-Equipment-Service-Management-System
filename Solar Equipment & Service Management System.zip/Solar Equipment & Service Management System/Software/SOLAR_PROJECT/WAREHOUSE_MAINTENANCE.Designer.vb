﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WAREHOUSE_MAINTENANCE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLWMED = New System.Windows.Forms.Label
        Me.TXTMID = New System.Windows.Forms.TextBox
        Me.TXTMTYPE = New System.Windows.Forms.TextBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.LBLMID = New System.Windows.Forms.Label
        Me.LBLMTYPE = New System.Windows.Forms.Label
        Me.LBLTE = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LBLWMED
        '
        Me.LBLWMED.AutoSize = True
        Me.LBLWMED.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLWMED.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLWMED.Location = New System.Drawing.Point(12, 9)
        Me.LBLWMED.Name = "LBLWMED"
        Me.LBLWMED.Size = New System.Drawing.Size(874, 56)
        Me.LBLWMED.TabIndex = 114
        Me.LBLWMED.Text = "WAREHOUSE MAINTENANCE DETAILS"
        '
        'TXTMID
        '
        Me.TXTMID.Location = New System.Drawing.Point(108, 191)
        Me.TXTMID.Name = "TXTMID"
        Me.TXTMID.Size = New System.Drawing.Size(100, 20)
        Me.TXTMID.TabIndex = 115
        '
        'TXTMTYPE
        '
        Me.TXTMTYPE.Location = New System.Drawing.Point(395, 191)
        Me.TXTMTYPE.Name = "TXTMTYPE"
        Me.TXTMTYPE.Size = New System.Drawing.Size(100, 20)
        Me.TXTMTYPE.TabIndex = 117
        '
        'TXTTE
        '
        Me.TXTTE.Location = New System.Drawing.Point(686, 191)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(100, 20)
        Me.TXTTE.TabIndex = 119
        '
        'LBLMID
        '
        Me.LBLMID.AutoSize = True
        Me.LBLMID.Location = New System.Drawing.Point(105, 153)
        Me.LBLMID.Name = "LBLMID"
        Me.LBLMID.Size = New System.Drawing.Size(99, 13)
        Me.LBLMID.TabIndex = 120
        Me.LBLMID.Text = "MAINTENANCE ID"
        '
        'LBLMTYPE
        '
        Me.LBLMTYPE.AutoSize = True
        Me.LBLMTYPE.Location = New System.Drawing.Point(392, 153)
        Me.LBLMTYPE.Name = "LBLMTYPE"
        Me.LBLMTYPE.Size = New System.Drawing.Size(116, 13)
        Me.LBLMTYPE.TabIndex = 121
        Me.LBLMTYPE.Text = "MAINTENANCE TYPE"
        '
        'LBLTE
        '
        Me.LBLTE.AutoSize = True
        Me.LBLTE.Location = New System.Drawing.Point(683, 153)
        Me.LBLTE.Name = "LBLTE"
        Me.LBLTE.Size = New System.Drawing.Size(95, 13)
        Me.LBLTE.TabIndex = 122
        Me.LBLTE.Text = "TOTAL EXPENSE"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(656, 255)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 126
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(512, 255)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 125
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(338, 255)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 124
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(157, 255)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 123
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'WAREHOUSE_MAINTENANCE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 461)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLTE)
        Me.Controls.Add(Me.LBLMTYPE)
        Me.Controls.Add(Me.LBLMID)
        Me.Controls.Add(Me.TXTTE)
        Me.Controls.Add(Me.TXTMTYPE)
        Me.Controls.Add(Me.TXTMID)
        Me.Controls.Add(Me.LBLWMED)
        Me.Name = "WAREHOUSE_MAINTENANCE"
        Me.Text = "MAINTENANCE FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLWMED As System.Windows.Forms.Label
    Friend WithEvents TXTMID As System.Windows.Forms.TextBox
    Friend WithEvents TXTMTYPE As System.Windows.Forms.TextBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents LBLMID As System.Windows.Forms.Label
    Friend WithEvents LBLMTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLTE As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
End Class
