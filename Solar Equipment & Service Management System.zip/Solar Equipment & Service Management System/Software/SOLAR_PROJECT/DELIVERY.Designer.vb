﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DELIVERY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLDELIVERY = New System.Windows.Forms.Label
        Me.LBLID = New System.Windows.Forms.Label
        Me.LBLADDR = New System.Windows.Forms.Label
        Me.LBLVID = New System.Windows.Forms.Label
        Me.LBLDID = New System.Windows.Forms.Label
        Me.LBLCID = New System.Windows.Forms.Label
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.LBLBTBP = New System.Windows.Forms.Label
        Me.LBLVNAME = New System.Windows.Forms.Label
        Me.LBLDNAME = New System.Windows.Forms.Label
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.TXTADDR = New System.Windows.Forms.TextBox
        Me.TXTVID = New System.Windows.Forms.TextBox
        Me.TXTDID = New System.Windows.Forms.TextBox
        Me.TXTCID = New System.Windows.Forms.TextBox
        Me.TXTDATE = New System.Windows.Forms.TextBox
        Me.TXTBTBP = New System.Windows.Forms.TextBox
        Me.TXTVNAME = New System.Windows.Forms.TextBox
        Me.TXTDNAME = New System.Windows.Forms.TextBox
        Me.TXTCNAME = New System.Windows.Forms.TextBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LBLDELIVERY
        '
        Me.LBLDELIVERY.AutoSize = True
        Me.LBLDELIVERY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLDELIVERY.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLDELIVERY.Location = New System.Drawing.Point(183, 27)
        Me.LBLDELIVERY.Name = "LBLDELIVERY"
        Me.LBLDELIVERY.Size = New System.Drawing.Size(465, 56)
        Me.LBLDELIVERY.TabIndex = 119
        Me.LBLDELIVERY.Text = "DELIVERY DETAILS"
        '
        'LBLID
        '
        Me.LBLID.AutoSize = True
        Me.LBLID.Location = New System.Drawing.Point(90, 126)
        Me.LBLID.Name = "LBLID"
        Me.LBLID.Size = New System.Drawing.Size(74, 13)
        Me.LBLID.TabIndex = 120
        Me.LBLID.Text = "DELIVERY ID"
        '
        'LBLADDR
        '
        Me.LBLADDR.AutoSize = True
        Me.LBLADDR.Location = New System.Drawing.Point(475, 340)
        Me.LBLADDR.Name = "LBLADDR"
        Me.LBLADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLADDR.TabIndex = 121
        Me.LBLADDR.Text = "ADDRESS"
        '
        'LBLVID
        '
        Me.LBLVID.AutoSize = True
        Me.LBLVID.Location = New System.Drawing.Point(475, 283)
        Me.LBLVID.Name = "LBLVID"
        Me.LBLVID.Size = New System.Drawing.Size(66, 13)
        Me.LBLVID.TabIndex = 122
        Me.LBLVID.Text = "VEHICLE ID"
        '
        'LBLDID
        '
        Me.LBLDID.AutoSize = True
        Me.LBLDID.Location = New System.Drawing.Point(475, 225)
        Me.LBLDID.Name = "LBLDID"
        Me.LBLDID.Size = New System.Drawing.Size(62, 13)
        Me.LBLDID.TabIndex = 123
        Me.LBLDID.Text = "DRIVER ID"
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(475, 172)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 124
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(475, 126)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLDATE.TabIndex = 125
        Me.LBLDATE.Text = "DATE"
        '
        'LBLBTBP
        '
        Me.LBLBTBP.AutoSize = True
        Me.LBLBTBP.Location = New System.Drawing.Point(90, 340)
        Me.LBLBTBP.Name = "LBLBTBP"
        Me.LBLBTBP.Size = New System.Drawing.Size(119, 13)
        Me.LBLBTBP.TabIndex = 126
        Me.LBLBTBP.Text = "BALANCE TO BE PAID"
        '
        'LBLVNAME
        '
        Me.LBLVNAME.AutoSize = True
        Me.LBLVNAME.Location = New System.Drawing.Point(90, 283)
        Me.LBLVNAME.Name = "LBLVNAME"
        Me.LBLVNAME.Size = New System.Drawing.Size(86, 13)
        Me.LBLVNAME.TabIndex = 127
        Me.LBLVNAME.Text = "VEHICLE NAME"
        '
        'LBLDNAME
        '
        Me.LBLDNAME.AutoSize = True
        Me.LBLDNAME.Location = New System.Drawing.Point(90, 225)
        Me.LBLDNAME.Name = "LBLDNAME"
        Me.LBLDNAME.Size = New System.Drawing.Size(82, 13)
        Me.LBLDNAME.TabIndex = 128
        Me.LBLDNAME.Text = "DRIVER NAME"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(90, 172)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(102, 13)
        Me.LBLCNAME.TabIndex = 129
        Me.LBLCNAME.Text = "CUSTOMER NAME"
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(241, 119)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(100, 20)
        Me.TXTID.TabIndex = 130
        '
        'TXTADDR
        '
        Me.TXTADDR.Location = New System.Drawing.Point(618, 340)
        Me.TXTADDR.Name = "TXTADDR"
        Me.TXTADDR.Size = New System.Drawing.Size(100, 20)
        Me.TXTADDR.TabIndex = 131
        '
        'TXTVID
        '
        Me.TXTVID.Location = New System.Drawing.Point(618, 283)
        Me.TXTVID.Name = "TXTVID"
        Me.TXTVID.Size = New System.Drawing.Size(100, 20)
        Me.TXTVID.TabIndex = 132
        '
        'TXTDID
        '
        Me.TXTDID.Location = New System.Drawing.Point(618, 225)
        Me.TXTDID.Name = "TXTDID"
        Me.TXTDID.Size = New System.Drawing.Size(100, 20)
        Me.TXTDID.TabIndex = 133
        '
        'TXTCID
        '
        Me.TXTCID.Location = New System.Drawing.Point(618, 172)
        Me.TXTCID.Name = "TXTCID"
        Me.TXTCID.Size = New System.Drawing.Size(100, 20)
        Me.TXTCID.TabIndex = 134
        '
        'TXTDATE
        '
        Me.TXTDATE.Location = New System.Drawing.Point(618, 119)
        Me.TXTDATE.Name = "TXTDATE"
        Me.TXTDATE.Size = New System.Drawing.Size(100, 20)
        Me.TXTDATE.TabIndex = 135
        '
        'TXTBTBP
        '
        Me.TXTBTBP.Location = New System.Drawing.Point(241, 333)
        Me.TXTBTBP.Name = "TXTBTBP"
        Me.TXTBTBP.Size = New System.Drawing.Size(100, 20)
        Me.TXTBTBP.TabIndex = 136
        '
        'TXTVNAME
        '
        Me.TXTVNAME.Location = New System.Drawing.Point(241, 276)
        Me.TXTVNAME.Name = "TXTVNAME"
        Me.TXTVNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTVNAME.TabIndex = 137
        '
        'TXTDNAME
        '
        Me.TXTDNAME.Location = New System.Drawing.Point(241, 218)
        Me.TXTDNAME.Name = "TXTDNAME"
        Me.TXTDNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTDNAME.TabIndex = 138
        '
        'TXTCNAME
        '
        Me.TXTCNAME.Location = New System.Drawing.Point(241, 165)
        Me.TXTCNAME.Name = "TXTCNAME"
        Me.TXTCNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTCNAME.TabIndex = 139
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(618, 380)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 143
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(474, 380)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 142
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(300, 380)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 141
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(119, 380)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 140
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'DELIVERY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 415)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.TXTCNAME)
        Me.Controls.Add(Me.TXTDNAME)
        Me.Controls.Add(Me.TXTVNAME)
        Me.Controls.Add(Me.TXTBTBP)
        Me.Controls.Add(Me.TXTDATE)
        Me.Controls.Add(Me.TXTCID)
        Me.Controls.Add(Me.TXTDID)
        Me.Controls.Add(Me.TXTVID)
        Me.Controls.Add(Me.TXTADDR)
        Me.Controls.Add(Me.TXTID)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Controls.Add(Me.LBLDNAME)
        Me.Controls.Add(Me.LBLVNAME)
        Me.Controls.Add(Me.LBLBTBP)
        Me.Controls.Add(Me.LBLDATE)
        Me.Controls.Add(Me.LBLCID)
        Me.Controls.Add(Me.LBLDID)
        Me.Controls.Add(Me.LBLVID)
        Me.Controls.Add(Me.LBLADDR)
        Me.Controls.Add(Me.LBLID)
        Me.Controls.Add(Me.LBLDELIVERY)
        Me.Name = "DELIVERY"
        Me.Text = "DELIVERY FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLDELIVERY As System.Windows.Forms.Label
    Friend WithEvents LBLID As System.Windows.Forms.Label
    Friend WithEvents LBLADDR As System.Windows.Forms.Label
    Friend WithEvents LBLVID As System.Windows.Forms.Label
    Friend WithEvents LBLDID As System.Windows.Forms.Label
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents LBLBTBP As System.Windows.Forms.Label
    Friend WithEvents LBLVNAME As System.Windows.Forms.Label
    Friend WithEvents LBLDNAME As System.Windows.Forms.Label
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents TXTADDR As System.Windows.Forms.TextBox
    Friend WithEvents TXTVID As System.Windows.Forms.TextBox
    Friend WithEvents TXTDID As System.Windows.Forms.TextBox
    Friend WithEvents TXTCID As System.Windows.Forms.TextBox
    Friend WithEvents TXTDATE As System.Windows.Forms.TextBox
    Friend WithEvents TXTBTBP As System.Windows.Forms.TextBox
    Friend WithEvents TXTVNAME As System.Windows.Forms.TextBox
    Friend WithEvents TXTDNAME As System.Windows.Forms.TextBox
    Friend WithEvents TXTCNAME As System.Windows.Forms.TextBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
End Class
