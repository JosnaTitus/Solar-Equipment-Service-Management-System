﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class STOCK
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.LBLMID = New System.Windows.Forms.Label
        Me.LBLMNAME = New System.Windows.Forms.Label
        Me.TXTMNAME = New System.Windows.Forms.TextBox
        Me.LBLVEHICLE = New System.Windows.Forms.Label
        Me.CMBMID = New System.Windows.Forms.ComboBox
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(403, 325)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 142
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'LBLMID
        '
        Me.LBLMID.AutoSize = True
        Me.LBLMID.Location = New System.Drawing.Point(290, 246)
        Me.LBLMID.Name = "LBLMID"
        Me.LBLMID.Size = New System.Drawing.Size(75, 13)
        Me.LBLMID.TabIndex = 140
        Me.LBLMID.Text = "MATERIAL ID"
        '
        'LBLMNAME
        '
        Me.LBLMNAME.AutoSize = True
        Me.LBLMNAME.Location = New System.Drawing.Point(290, 188)
        Me.LBLMNAME.Name = "LBLMNAME"
        Me.LBLMNAME.Size = New System.Drawing.Size(95, 13)
        Me.LBLMNAME.TabIndex = 139
        Me.LBLMNAME.Text = "MATERIAL NAME"
        '
        'TXTMNAME
        '
        Me.TXTMNAME.Location = New System.Drawing.Point(492, 181)
        Me.TXTMNAME.Name = "TXTMNAME"
        Me.TXTMNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTMNAME.TabIndex = 137
        '
        'LBLVEHICLE
        '
        Me.LBLVEHICLE.AutoSize = True
        Me.LBLVEHICLE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLVEHICLE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLVEHICLE.Location = New System.Drawing.Point(253, 83)
        Me.LBLVEHICLE.Name = "LBLVEHICLE"
        Me.LBLVEHICLE.Size = New System.Drawing.Size(386, 56)
        Me.LBLVEHICLE.TabIndex = 136
        Me.LBLVEHICLE.Text = "STOCK DETAILS"
        '
        'CMBMID
        '
        Me.CMBMID.FormattingEnabled = True
        Me.CMBMID.Location = New System.Drawing.Point(492, 246)
        Me.CMBMID.Name = "CMBMID"
        Me.CMBMID.Size = New System.Drawing.Size(121, 21)
        Me.CMBMID.TabIndex = 143
        '
        'STOCK
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 406)
        Me.Controls.Add(Me.CMBMID)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.LBLMID)
        Me.Controls.Add(Me.LBLMNAME)
        Me.Controls.Add(Me.TXTMNAME)
        Me.Controls.Add(Me.LBLVEHICLE)
        Me.Name = "STOCK"
        Me.Text = "STOCK FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents LBLMID As System.Windows.Forms.Label
    Friend WithEvents LBLMNAME As System.Windows.Forms.Label
    Friend WithEvents TXTMNAME As System.Windows.Forms.TextBox
    Friend WithEvents LBLVEHICLE As System.Windows.Forms.Label
    Friend WithEvents CMBMID As System.Windows.Forms.ComboBox
End Class
