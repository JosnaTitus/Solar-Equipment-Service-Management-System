﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EMPLOYEE_SALARY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLNAME = New System.Windows.Forms.Label
        Me.LBLBASIC = New System.Windows.Forms.Label
        Me.LBLPOST = New System.Windows.Forms.Label
        Me.LBLSALID = New System.Windows.Forms.Label
        Me.LBLLEAVES = New System.Windows.Forms.Label
        Me.LBLNET = New System.Windows.Forms.Label
        Me.BTNCALCULATE = New System.Windows.Forms.Button
        Me.TXTNAME = New System.Windows.Forms.TextBox
        Me.TXTNET = New System.Windows.Forms.TextBox
        Me.TXTBASIC = New System.Windows.Forms.TextBox
        Me.TXTSALID = New System.Windows.Forms.TextBox
        Me.TXTLEAVES = New System.Windows.Forms.TextBox
        Me.CMBPOST = New System.Windows.Forms.ComboBox
        Me.LBLSAL = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LBLNAME
        '
        Me.LBLNAME.AutoSize = True
        Me.LBLNAME.Location = New System.Drawing.Point(168, 140)
        Me.LBLNAME.Name = "LBLNAME"
        Me.LBLNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLNAME.TabIndex = 0
        Me.LBLNAME.Text = "NAME"
        '
        'LBLBASIC
        '
        Me.LBLBASIC.AutoSize = True
        Me.LBLBASIC.Location = New System.Drawing.Point(168, 264)
        Me.LBLBASIC.Name = "LBLBASIC"
        Me.LBLBASIC.Size = New System.Drawing.Size(83, 13)
        Me.LBLBASIC.TabIndex = 1
        Me.LBLBASIC.Text = "BASIC SALARY"
        '
        'LBLPOST
        '
        Me.LBLPOST.AutoSize = True
        Me.LBLPOST.Location = New System.Drawing.Point(168, 202)
        Me.LBLPOST.Name = "LBLPOST"
        Me.LBLPOST.Size = New System.Drawing.Size(36, 13)
        Me.LBLPOST.TabIndex = 2
        Me.LBLPOST.Text = "POST"
        '
        'LBLSALID
        '
        Me.LBLSALID.AutoSize = True
        Me.LBLSALID.Location = New System.Drawing.Point(168, 326)
        Me.LBLSALID.Name = "LBLSALID"
        Me.LBLSALID.Size = New System.Drawing.Size(63, 13)
        Me.LBLSALID.TabIndex = 3
        Me.LBLSALID.Text = "SALARY ID"
        '
        'LBLLEAVES
        '
        Me.LBLLEAVES.AutoSize = True
        Me.LBLLEAVES.Location = New System.Drawing.Point(168, 388)
        Me.LBLLEAVES.Name = "LBLLEAVES"
        Me.LBLLEAVES.Size = New System.Drawing.Size(115, 13)
        Me.LBLLEAVES.TabIndex = 4
        Me.LBLLEAVES.Text = "NUMBER OF LEAVES"
        '
        'LBLNET
        '
        Me.LBLNET.AutoSize = True
        Me.LBLNET.Location = New System.Drawing.Point(168, 492)
        Me.LBLNET.Name = "LBLNET"
        Me.LBLNET.Size = New System.Drawing.Size(74, 13)
        Me.LBLNET.TabIndex = 5
        Me.LBLNET.Text = "NET SALARY"
        '
        'BTNCALCULATE
        '
        Me.BTNCALCULATE.Location = New System.Drawing.Point(245, 432)
        Me.BTNCALCULATE.Name = "BTNCALCULATE"
        Me.BTNCALCULATE.Size = New System.Drawing.Size(211, 23)
        Me.BTNCALCULATE.TabIndex = 6
        Me.BTNCALCULATE.Text = "CALCULATE SALARY"
        Me.BTNCALCULATE.UseVisualStyleBackColor = True
        '
        'TXTNAME
        '
        Me.TXTNAME.Location = New System.Drawing.Point(373, 136)
        Me.TXTNAME.Name = "TXTNAME"
        Me.TXTNAME.Size = New System.Drawing.Size(139, 20)
        Me.TXTNAME.TabIndex = 7
        '
        'TXTNET
        '
        Me.TXTNET.Location = New System.Drawing.Point(373, 485)
        Me.TXTNET.Name = "TXTNET"
        Me.TXTNET.Size = New System.Drawing.Size(139, 20)
        Me.TXTNET.TabIndex = 8
        '
        'TXTBASIC
        '
        Me.TXTBASIC.Location = New System.Drawing.Point(373, 259)
        Me.TXTBASIC.Name = "TXTBASIC"
        Me.TXTBASIC.Size = New System.Drawing.Size(139, 20)
        Me.TXTBASIC.TabIndex = 9
        '
        'TXTSALID
        '
        Me.TXTSALID.Location = New System.Drawing.Point(373, 320)
        Me.TXTSALID.Name = "TXTSALID"
        Me.TXTSALID.Size = New System.Drawing.Size(139, 20)
        Me.TXTSALID.TabIndex = 10
        '
        'TXTLEAVES
        '
        Me.TXTLEAVES.Location = New System.Drawing.Point(373, 381)
        Me.TXTLEAVES.Name = "TXTLEAVES"
        Me.TXTLEAVES.Size = New System.Drawing.Size(139, 20)
        Me.TXTLEAVES.TabIndex = 11
        '
        'CMBPOST
        '
        Me.CMBPOST.FormattingEnabled = True
        Me.CMBPOST.Location = New System.Drawing.Point(373, 197)
        Me.CMBPOST.Name = "CMBPOST"
        Me.CMBPOST.Size = New System.Drawing.Size(139, 21)
        Me.CMBPOST.TabIndex = 12
        '
        'LBLSAL
        '
        Me.LBLSAL.AutoSize = True
        Me.LBLSAL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLSAL.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSAL.Location = New System.Drawing.Point(132, 18)
        Me.LBLSAL.Name = "LBLSAL"
        Me.LBLSAL.Size = New System.Drawing.Size(428, 56)
        Me.LBLSAL.TabIndex = 72
        Me.LBLSAL.Text = "SALARY DETAILS"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(648, 572)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 41)
        Me.BTNEXIT.TabIndex = 82
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(484, 572)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 41)
        Me.BTNCLEAR.TabIndex = 81
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(310, 572)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 41)
        Me.BTNSAVE.TabIndex = 80
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(129, 572)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 41)
        Me.BTNADDNEW.TabIndex = 79
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'EMPLOYEE_SALARY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(889, 649)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLSAL)
        Me.Controls.Add(Me.CMBPOST)
        Me.Controls.Add(Me.TXTLEAVES)
        Me.Controls.Add(Me.TXTSALID)
        Me.Controls.Add(Me.TXTBASIC)
        Me.Controls.Add(Me.TXTNET)
        Me.Controls.Add(Me.TXTNAME)
        Me.Controls.Add(Me.BTNCALCULATE)
        Me.Controls.Add(Me.LBLNET)
        Me.Controls.Add(Me.LBLLEAVES)
        Me.Controls.Add(Me.LBLSALID)
        Me.Controls.Add(Me.LBLPOST)
        Me.Controls.Add(Me.LBLBASIC)
        Me.Controls.Add(Me.LBLNAME)
        Me.Name = "EMPLOYEE_SALARY"
        Me.Text = "EMPLOYEE SALARY FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLNAME As System.Windows.Forms.Label
    Friend WithEvents LBLBASIC As System.Windows.Forms.Label
    Friend WithEvents LBLPOST As System.Windows.Forms.Label
    Friend WithEvents LBLSALID As System.Windows.Forms.Label
    Friend WithEvents LBLLEAVES As System.Windows.Forms.Label
    Friend WithEvents LBLNET As System.Windows.Forms.Label
    Friend WithEvents BTNCALCULATE As System.Windows.Forms.Button
    Friend WithEvents TXTNAME As System.Windows.Forms.TextBox
    Friend WithEvents TXTNET As System.Windows.Forms.TextBox
    Friend WithEvents TXTBASIC As System.Windows.Forms.TextBox
    Friend WithEvents TXTSALID As System.Windows.Forms.TextBox
    Friend WithEvents TXTLEAVES As System.Windows.Forms.TextBox
    Friend WithEvents CMBPOST As System.Windows.Forms.ComboBox
    Friend WithEvents LBLSAL As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
End Class
