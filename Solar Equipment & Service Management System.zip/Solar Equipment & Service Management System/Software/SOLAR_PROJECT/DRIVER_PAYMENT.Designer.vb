﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DRIVER_PAYMENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TXTAMT = New System.Windows.Forms.TextBox
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.CMBSNAME = New System.Windows.Forms.ComboBox
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTPNO = New System.Windows.Forms.TextBox
        Me.CMBDATE = New System.Windows.Forms.ComboBox
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.LBLDPAYMENT = New System.Windows.Forms.Label
        Me.TXTINVOICE = New System.Windows.Forms.TextBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.LBLPID = New System.Windows.Forms.Label
        Me.RADCASH = New System.Windows.Forms.RadioButton
        Me.RADCHEQUE = New System.Windows.Forms.RadioButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.LBLSNAME = New System.Windows.Forms.Label
        Me.LBLINVOICE = New System.Windows.Forms.Label
        Me.CMBDNAME = New System.Windows.Forms.ComboBox
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.LBLDNAME = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TXTAMT
        '
        Me.TXTAMT.Location = New System.Drawing.Point(225, 374)
        Me.TXTAMT.Name = "TXTAMT"
        Me.TXTAMT.Size = New System.Drawing.Size(100, 20)
        Me.TXTAMT.TabIndex = 112
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(27, 408)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(91, 13)
        Me.LBLDATE.TabIndex = 6
        Me.LBLDATE.Text = "PAYMENT DATE"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(650, 591)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 117
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(506, 591)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 116
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(332, 591)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 115
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'CMBSNAME
        '
        Me.CMBSNAME.FormattingEnabled = True
        Me.CMBSNAME.Location = New System.Drawing.Point(558, 348)
        Me.CMBSNAME.Name = "CMBSNAME"
        Me.CMBSNAME.Size = New System.Drawing.Size(121, 21)
        Me.CMBSNAME.TabIndex = 15
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(151, 591)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 114
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTPNO
        '
        Me.TXTPNO.Location = New System.Drawing.Point(184, 351)
        Me.TXTPNO.Name = "TXTPNO"
        Me.TXTPNO.Size = New System.Drawing.Size(121, 20)
        Me.TXTPNO.TabIndex = 10
        '
        'CMBDATE
        '
        Me.CMBDATE.FormattingEnabled = True
        Me.CMBDATE.Location = New System.Drawing.Point(184, 408)
        Me.CMBDATE.Name = "CMBDATE"
        Me.CMBDATE.Size = New System.Drawing.Size(121, 21)
        Me.CMBDATE.TabIndex = 14
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(55, 414)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(790, 150)
        Me.DataGridView2.TabIndex = 113
        '
        'LBLDPAYMENT
        '
        Me.LBLDPAYMENT.AutoSize = True
        Me.LBLDPAYMENT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLDPAYMENT.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLDPAYMENT.Location = New System.Drawing.Point(85, 9)
        Me.LBLDPAYMENT.Name = "LBLDPAYMENT"
        Me.LBLDPAYMENT.Size = New System.Drawing.Size(643, 56)
        Me.LBLDPAYMENT.TabIndex = 118
        Me.LBLDPAYMENT.Text = "DRIVER PAYMENT DETAILS"
        '
        'TXTINVOICE
        '
        Me.TXTINVOICE.Location = New System.Drawing.Point(558, 401)
        Me.TXTINVOICE.Name = "TXTINVOICE"
        Me.TXTINVOICE.Size = New System.Drawing.Size(121, 20)
        Me.TXTINVOICE.TabIndex = 12
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(55, 194)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(790, 150)
        Me.DataGridView1.TabIndex = 110
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(68, 374)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 107
        Me.LBLAMT.Text = "AMOUNT"
        '
        'LBLPID
        '
        Me.LBLPID.AutoSize = True
        Me.LBLPID.Location = New System.Drawing.Point(27, 351)
        Me.LBLPID.Name = "LBLPID"
        Me.LBLPID.Size = New System.Drawing.Size(78, 13)
        Me.LBLPID.TabIndex = 0
        Me.LBLPID.Text = "PAYMENT NO"
        '
        'RADCASH
        '
        Me.RADCASH.AutoSize = True
        Me.RADCASH.Location = New System.Drawing.Point(471, 375)
        Me.RADCASH.Name = "RADCASH"
        Me.RADCASH.Size = New System.Drawing.Size(54, 17)
        Me.RADCASH.TabIndex = 108
        Me.RADCASH.TabStop = True
        Me.RADCASH.Text = "CASH"
        Me.RADCASH.UseVisualStyleBackColor = True
        '
        'RADCHEQUE
        '
        Me.RADCHEQUE.AutoSize = True
        Me.RADCHEQUE.Location = New System.Drawing.Point(678, 377)
        Me.RADCHEQUE.Name = "RADCHEQUE"
        Me.RADCHEQUE.Size = New System.Drawing.Size(70, 17)
        Me.RADCHEQUE.TabIndex = 109
        Me.RADCHEQUE.TabStop = True
        Me.RADCHEQUE.Text = "CHEQUE"
        Me.RADCHEQUE.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CMBDNAME)
        Me.Panel1.Controls.Add(Me.ComboBox2)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.LBLDNAME)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.CMBSNAME)
        Me.Panel1.Controls.Add(Me.CMBDATE)
        Me.Panel1.Controls.Add(Me.TXTINVOICE)
        Me.Panel1.Controls.Add(Me.TXTPNO)
        Me.Panel1.Controls.Add(Me.LBLDATE)
        Me.Panel1.Controls.Add(Me.LBLSNAME)
        Me.Panel1.Controls.Add(Me.LBLINVOICE)
        Me.Panel1.Controls.Add(Me.LBLPID)
        Me.Panel1.Location = New System.Drawing.Point(55, 78)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(790, 110)
        Me.Panel1.TabIndex = 111
        '
        'LBLSNAME
        '
        Me.LBLSNAME.AutoSize = True
        Me.LBLSNAME.Location = New System.Drawing.Point(427, 351)
        Me.LBLSNAME.Name = "LBLSNAME"
        Me.LBLSNAME.Size = New System.Drawing.Size(94, 13)
        Me.LBLSNAME.TabIndex = 5
        Me.LBLSNAME.Text = "SUPPLIER NAME"
        '
        'LBLINVOICE
        '
        Me.LBLINVOICE.AutoSize = True
        Me.LBLINVOICE.Location = New System.Drawing.Point(427, 408)
        Me.LBLINVOICE.Name = "LBLINVOICE"
        Me.LBLINVOICE.Size = New System.Drawing.Size(69, 13)
        Me.LBLINVOICE.TabIndex = 4
        Me.LBLINVOICE.Text = "INVOICE NO"
        '
        'CMBDNAME
        '
        Me.CMBDNAME.FormattingEnabled = True
        Me.CMBDNAME.Location = New System.Drawing.Point(600, 15)
        Me.CMBDNAME.Name = "CMBDNAME"
        Me.CMBDNAME.Size = New System.Drawing.Size(151, 21)
        Me.CMBDNAME.TabIndex = 23
        Me.CMBDNAME.Text = "SELECT DRIVER NAME"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(226, 75)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 22
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(600, 68)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(151, 20)
        Me.TextBox1.TabIndex = 21
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(226, 18)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(121, 20)
        Me.TextBox2.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "PAYMENT DATE"
        '
        'LBLDNAME
        '
        Me.LBLDNAME.AutoSize = True
        Me.LBLDNAME.Location = New System.Drawing.Point(469, 18)
        Me.LBLDNAME.Name = "LBLDNAME"
        Me.LBLDNAME.Size = New System.Drawing.Size(82, 13)
        Me.LBLDNAME.TabIndex = 18
        Me.LBLDNAME.Text = "DRIVER NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(469, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "INVOICE NO"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(69, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "PAYMENT NO"
        '
        'DRIVER_PAYMENT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 634)
        Me.Controls.Add(Me.TXTAMT)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.LBLDPAYMENT)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.RADCASH)
        Me.Controls.Add(Me.RADCHEQUE)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "DRIVER_PAYMENT"
        Me.Text = "DRIVER PAYMENT FORM"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXTAMT As System.Windows.Forms.TextBox
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents CMBSNAME As System.Windows.Forms.ComboBox
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTPNO As System.Windows.Forms.TextBox
    Friend WithEvents CMBDATE As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents LBLDPAYMENT As System.Windows.Forms.Label
    Friend WithEvents TXTINVOICE As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents LBLPID As System.Windows.Forms.Label
    Friend WithEvents RADCASH As System.Windows.Forms.RadioButton
    Friend WithEvents RADCHEQUE As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents LBLSNAME As System.Windows.Forms.Label
    Friend WithEvents LBLINVOICE As System.Windows.Forms.Label
    Friend WithEvents CMBDNAME As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LBLDNAME As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
