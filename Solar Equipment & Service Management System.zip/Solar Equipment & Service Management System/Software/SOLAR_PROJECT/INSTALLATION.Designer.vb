﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class INSTALLATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.LBLCID = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.LBLCPHNO = New System.Windows.Forms.Label
        Me.LBLCMNO = New System.Windows.Forms.Label
        Me.LBLCADDR = New System.Windows.Forms.Label
        Me.CMBCNAME = New System.Windows.Forms.ComboBox
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.TXT50000 = New System.Windows.Forms.TextBox
        Me.TXT30000 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.CHKUTILITY = New System.Windows.Forms.CheckBox
        Me.CHKRESIDENTIAL = New System.Windows.Forms.CheckBox
        Me.CHKCOMMERCIAL = New System.Windows.Forms.CheckBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.TXT1500 = New System.Windows.Forms.TextBox
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.LBLINSTALLATION = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(153, 18)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(219, 20)
        Me.TXTID.TabIndex = 183
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(18, 25)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 182
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(153, 173)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(219, 20)
        Me.TextBox9.TabIndex = 181
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TXTID)
        Me.Panel1.Controls.Add(Me.LBLCID)
        Me.Panel1.Controls.Add(Me.TextBox9)
        Me.Panel1.Controls.Add(Me.TextBox7)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.LBLCPHNO)
        Me.Panel1.Controls.Add(Me.LBLCMNO)
        Me.Panel1.Controls.Add(Me.LBLCADDR)
        Me.Panel1.Location = New System.Drawing.Point(36, 137)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(814, 213)
        Me.Panel1.TabIndex = 202
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(582, 173)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(219, 20)
        Me.TextBox7.TabIndex = 180
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(153, 78)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(219, 70)
        Me.TextBox2.TabIndex = 179
        '
        'LBLCPHNO
        '
        Me.LBLCPHNO.AutoSize = True
        Me.LBLCPHNO.Location = New System.Drawing.Point(450, 180)
        Me.LBLCPHNO.Name = "LBLCPHNO"
        Me.LBLCPHNO.Size = New System.Drawing.Size(121, 13)
        Me.LBLCPHNO.TabIndex = 177
        Me.LBLCPHNO.Text = "ALTERNATE NUMBER"
        '
        'LBLCMNO
        '
        Me.LBLCMNO.AutoSize = True
        Me.LBLCMNO.Location = New System.Drawing.Point(18, 180)
        Me.LBLCMNO.Name = "LBLCMNO"
        Me.LBLCMNO.Size = New System.Drawing.Size(97, 13)
        Me.LBLCMNO.TabIndex = 176
        Me.LBLCMNO.Text = "MOBILE NUMBER"
        '
        'LBLCADDR
        '
        Me.LBLCADDR.AutoSize = True
        Me.LBLCADDR.Location = New System.Drawing.Point(21, 91)
        Me.LBLCADDR.Name = "LBLCADDR"
        Me.LBLCADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLCADDR.TabIndex = 175
        Me.LBLCADDR.Text = "ADDRESS"
        '
        'CMBCNAME
        '
        Me.CMBCNAME.FormattingEnabled = True
        Me.CMBCNAME.Location = New System.Drawing.Point(189, 91)
        Me.CMBCNAME.Name = "CMBCNAME"
        Me.CMBCNAME.Size = New System.Drawing.Size(219, 21)
        Me.CMBCNAME.TabIndex = 201
        Me.CMBCNAME.Text = "SELECT CUSTOMER NAME"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(57, 99)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 200
        Me.LBLCNAME.Text = "NAME"
        '
        'TXT50000
        '
        Me.TXT50000.Enabled = False
        Me.TXT50000.Location = New System.Drawing.Point(442, 478)
        Me.TXT50000.Name = "TXT50000"
        Me.TXT50000.Size = New System.Drawing.Size(121, 20)
        Me.TXT50000.TabIndex = 198
        Me.TXT50000.Text = "RS. 50000"
        '
        'TXT30000
        '
        Me.TXT30000.Enabled = False
        Me.TXT30000.Location = New System.Drawing.Point(442, 432)
        Me.TXT30000.Name = "TXT30000"
        Me.TXT30000.Size = New System.Drawing.Size(121, 20)
        Me.TXT30000.TabIndex = 197
        Me.TXT30000.Text = "RS. 30000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(122, 379)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(485, 31)
        Me.Label1.TabIndex = 196
        Me.Label1.Text = "INSTALLATION SERVICE DETAILS"
        '
        'CHKUTILITY
        '
        Me.CHKUTILITY.AutoSize = True
        Me.CHKUTILITY.Location = New System.Drawing.Point(159, 527)
        Me.CHKUTILITY.Name = "CHKUTILITY"
        Me.CHKUTILITY.Size = New System.Drawing.Size(104, 17)
        Me.CHKUTILITY.TabIndex = 195
        Me.CHKUTILITY.Text = "UTILITY-SCALE"
        Me.CHKUTILITY.UseVisualStyleBackColor = True
        '
        'CHKRESIDENTIAL
        '
        Me.CHKRESIDENTIAL.AutoSize = True
        Me.CHKRESIDENTIAL.Location = New System.Drawing.Point(159, 435)
        Me.CHKRESIDENTIAL.Name = "CHKRESIDENTIAL"
        Me.CHKRESIDENTIAL.Size = New System.Drawing.Size(97, 17)
        Me.CHKRESIDENTIAL.TabIndex = 193
        Me.CHKRESIDENTIAL.Text = "RESIDENTIAL"
        Me.CHKRESIDENTIAL.UseVisualStyleBackColor = True
        '
        'CHKCOMMERCIAL
        '
        Me.CHKCOMMERCIAL.AutoSize = True
        Me.CHKCOMMERCIAL.Location = New System.Drawing.Point(159, 481)
        Me.CHKCOMMERCIAL.Name = "CHKCOMMERCIAL"
        Me.CHKCOMMERCIAL.Size = New System.Drawing.Size(97, 17)
        Me.CHKCOMMERCIAL.TabIndex = 194
        Me.CHKCOMMERCIAL.Text = "COMMERCIAL"
        Me.CHKCOMMERCIAL.UseVisualStyleBackColor = True
        '
        'TXTTE
        '
        Me.TXTTE.Enabled = False
        Me.TXTTE.Location = New System.Drawing.Point(443, 575)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(120, 20)
        Me.TXTTE.TabIndex = 192
        Me.TXTTE.Text = "RS."
        '
        'TXT1500
        '
        Me.TXT1500.Location = New System.Drawing.Point(442, 527)
        Me.TXT1500.Name = "TXT1500"
        Me.TXT1500.Size = New System.Drawing.Size(121, 20)
        Me.TXT1500.TabIndex = 199
        Me.TXT1500.Text = "RS. 1500"
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(157, 575)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 191
        Me.LBLAMT.Text = "AMOUNT"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(586, 632)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 190
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(442, 632)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 189
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(268, 632)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 188
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(87, 632)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 187
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'LBLINSTALLATION
        '
        Me.LBLINSTALLATION.AutoSize = True
        Me.LBLINSTALLATION.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLINSTALLATION.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLINSTALLATION.Location = New System.Drawing.Point(189, 9)
        Me.LBLINSTALLATION.Name = "LBLINSTALLATION"
        Me.LBLINSTALLATION.Size = New System.Drawing.Size(573, 56)
        Me.LBLINSTALLATION.TabIndex = 186
        Me.LBLINSTALLATION.Text = "INSTALLATION DETAILS"
        '
        'INSTALLATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 687)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CMBCNAME)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Controls.Add(Me.TXT50000)
        Me.Controls.Add(Me.TXT30000)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CHKUTILITY)
        Me.Controls.Add(Me.CHKRESIDENTIAL)
        Me.Controls.Add(Me.CHKCOMMERCIAL)
        Me.Controls.Add(Me.TXTTE)
        Me.Controls.Add(Me.TXT1500)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLINSTALLATION)
        Me.Name = "INSTALLATION"
        Me.Text = "B"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents LBLCPHNO As System.Windows.Forms.Label
    Friend WithEvents LBLCMNO As System.Windows.Forms.Label
    Friend WithEvents LBLCADDR As System.Windows.Forms.Label
    Friend WithEvents CMBCNAME As System.Windows.Forms.ComboBox
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents TXT50000 As System.Windows.Forms.TextBox
    Friend WithEvents TXT30000 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CHKUTILITY As System.Windows.Forms.CheckBox
    Friend WithEvents CHKRESIDENTIAL As System.Windows.Forms.CheckBox
    Friend WithEvents CHKCOMMERCIAL As System.Windows.Forms.CheckBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents TXT1500 As System.Windows.Forms.TextBox
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents LBLINSTALLATION As System.Windows.Forms.Label
End Class
