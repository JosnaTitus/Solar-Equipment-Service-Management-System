﻿Public Class SUPPLIER_PAYMENT

    Private Sub SUPPLIER_PAYMENT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class