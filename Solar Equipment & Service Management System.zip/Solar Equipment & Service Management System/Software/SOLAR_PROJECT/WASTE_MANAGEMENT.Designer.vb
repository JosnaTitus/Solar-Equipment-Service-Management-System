﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WASTE_MANAGEMENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.LBLWID = New System.Windows.Forms.Label
        Me.TXTAMT = New System.Windows.Forms.TextBox
        Me.TXTCNAME = New System.Windows.Forms.TextBox
        Me.TXTWID = New System.Windows.Forms.TextBox
        Me.LBLWAREHOUSE = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(713, 398)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 148
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(569, 398)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 147
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(397, 398)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 146
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(214, 398)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 145
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(319, 315)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 144
        Me.LBLAMT.Text = "AMOUNT"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(319, 234)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(102, 13)
        Me.LBLCNAME.TabIndex = 143
        Me.LBLCNAME.Text = "CUSTOMER NAME"
        '
        'LBLWID
        '
        Me.LBLWID.AutoSize = True
        Me.LBLWID.Location = New System.Drawing.Point(319, 154)
        Me.LBLWID.Name = "LBLWID"
        Me.LBLWID.Size = New System.Drawing.Size(60, 13)
        Me.LBLWID.TabIndex = 142
        Me.LBLWID.Text = "WASTE ID"
        '
        'TXTAMT
        '
        Me.TXTAMT.Location = New System.Drawing.Point(534, 315)
        Me.TXTAMT.Name = "TXTAMT"
        Me.TXTAMT.Size = New System.Drawing.Size(100, 20)
        Me.TXTAMT.TabIndex = 141
        '
        'TXTCNAME
        '
        Me.TXTCNAME.Location = New System.Drawing.Point(534, 227)
        Me.TXTCNAME.Name = "TXTCNAME"
        Me.TXTCNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTCNAME.TabIndex = 140
        '
        'TXTWID
        '
        Me.TXTWID.Location = New System.Drawing.Point(534, 147)
        Me.TXTWID.Name = "TXTWID"
        Me.TXTWID.Size = New System.Drawing.Size(100, 20)
        Me.TXTWID.TabIndex = 139
        '
        'LBLWAREHOUSE
        '
        Me.LBLWAREHOUSE.AutoSize = True
        Me.LBLWAREHOUSE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLWAREHOUSE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLWAREHOUSE.Location = New System.Drawing.Point(179, 38)
        Me.LBLWAREHOUSE.Name = "LBLWAREHOUSE"
        Me.LBLWAREHOUSE.Size = New System.Drawing.Size(567, 56)
        Me.LBLWAREHOUSE.TabIndex = 138
        Me.LBLWAREHOUSE.Text = "WASTE GOODS DETAILS"
        '
        'WASTE_MANAGEMENT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(885, 463)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Controls.Add(Me.LBLWID)
        Me.Controls.Add(Me.TXTAMT)
        Me.Controls.Add(Me.TXTCNAME)
        Me.Controls.Add(Me.TXTWID)
        Me.Controls.Add(Me.LBLWAREHOUSE)
        Me.Name = "WASTE_MANAGEMENT"
        Me.Text = "WASTE_MANAGEMENT"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents LBLWID As System.Windows.Forms.Label
    Friend WithEvents TXTAMT As System.Windows.Forms.TextBox
    Friend WithEvents TXTCNAME As System.Windows.Forms.TextBox
    Friend WithEvents TXTWID As System.Windows.Forms.TextBox
    Friend WithEvents LBLWAREHOUSE As System.Windows.Forms.Label
End Class
