﻿Public Class EMPLOYEE_SALARY

End Class