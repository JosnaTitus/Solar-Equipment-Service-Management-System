﻿Imports System.Data.OleDb
Imports System.Data
Public Class CUSTOMER_BILL
    Dim CON As OleDbConnection
    Dim CMD As OleDbCommand
    Private Sub BTNSAVE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNSAVE.Click
        CON = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=F:\SOLAR PROJECT\SOLAR DATABASE\SOLAR_DB.mdb")
        CON.Open()
        CMD = New OleDbCommand("SELECT * FROM CUTOMER", CON)
        CMD.CommandText = "INSERT INTO CUTOMER VALUES(" & TXTCID.Text & ")"
        CMD.ExecuteNonQuery()
        MessageBox.Show("RECORD SAVED")
        CON.Close()
    End Sub

    Private Sub CUSTOMER_BILL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class