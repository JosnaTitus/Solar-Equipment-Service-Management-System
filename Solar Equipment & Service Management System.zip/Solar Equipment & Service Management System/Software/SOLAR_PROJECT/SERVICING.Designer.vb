﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SERVICING
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TXT15000 = New System.Windows.Forms.TextBox
        Me.TXT30000 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.CHKREPLACE = New System.Windows.Forms.CheckBox
        Me.CHKCABLING = New System.Windows.Forms.CheckBox
        Me.CHKREPAIR = New System.Windows.Forms.CheckBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.TXTRS = New System.Windows.Forms.TextBox
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.LBLSERVICING = New System.Windows.Forms.Label
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.LBLCID = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.LBLCPHNO = New System.Windows.Forms.Label
        Me.LBLCMNO = New System.Windows.Forms.Label
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.LBLCADDR = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.CMBCNAME = New System.Windows.Forms.ComboBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.CHKINSTALL = New System.Windows.Forms.CheckBox
        Me.TXT50000 = New System.Windows.Forms.TextBox
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TXT15000
        '
        Me.TXT15000.Enabled = False
        Me.TXT15000.Location = New System.Drawing.Point(443, 478)
        Me.TXT15000.Name = "TXT15000"
        Me.TXT15000.Size = New System.Drawing.Size(121, 20)
        Me.TXT15000.TabIndex = 172
        Me.TXT15000.Text = "RS. 15000"
        '
        'TXT30000
        '
        Me.TXT30000.Enabled = False
        Me.TXT30000.Location = New System.Drawing.Point(443, 432)
        Me.TXT30000.Name = "TXT30000"
        Me.TXT30000.Size = New System.Drawing.Size(121, 20)
        Me.TXT30000.TabIndex = 171
        Me.TXT30000.Text = "RS. 30000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(219, 377)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(270, 31)
        Me.Label1.TabIndex = 170
        Me.Label1.Text = "SERVICE DETAILS"
        '
        'CHKREPLACE
        '
        Me.CHKREPLACE.AutoSize = True
        Me.CHKREPLACE.Location = New System.Drawing.Point(160, 527)
        Me.CHKREPLACE.Name = "CHKREPLACE"
        Me.CHKREPLACE.Size = New System.Drawing.Size(145, 17)
        Me.CHKREPLACE.TabIndex = 169
        Me.CHKREPLACE.Text = "PARTS REPLACEMENT"
        Me.CHKREPLACE.UseVisualStyleBackColor = True
        '
        'CHKCABLING
        '
        Me.CHKCABLING.AutoSize = True
        Me.CHKCABLING.Location = New System.Drawing.Point(160, 435)
        Me.CHKCABLING.Name = "CHKCABLING"
        Me.CHKCABLING.Size = New System.Drawing.Size(118, 17)
        Me.CHKCABLING.TabIndex = 167
        Me.CHKCABLING.Text = "CABLING/WIRING"
        Me.CHKCABLING.UseVisualStyleBackColor = True
        '
        'CHKREPAIR
        '
        Me.CHKREPAIR.AutoSize = True
        Me.CHKREPAIR.Location = New System.Drawing.Point(160, 481)
        Me.CHKREPAIR.Name = "CHKREPAIR"
        Me.CHKREPAIR.Size = New System.Drawing.Size(85, 17)
        Me.CHKREPAIR.TabIndex = 168
        Me.CHKREPAIR.Text = "REPAIRING"
        Me.CHKREPAIR.UseVisualStyleBackColor = True
        '
        'TXTTE
        '
        Me.TXTTE.Enabled = False
        Me.TXTTE.Location = New System.Drawing.Point(444, 631)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(120, 20)
        Me.TXTTE.TabIndex = 165
        Me.TXTTE.Text = "RS."
        '
        'TXTRS
        '
        Me.TXTRS.Location = New System.Drawing.Point(443, 527)
        Me.TXTRS.Name = "TXTRS"
        Me.TXTRS.Size = New System.Drawing.Size(121, 20)
        Me.TXTRS.TabIndex = 173
        Me.TXTRS.Text = "RS. "
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(158, 631)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 164
        Me.LBLAMT.Text = "AMOUNT"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(587, 688)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 162
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(443, 688)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 161
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(269, 688)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 160
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(88, 688)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 159
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'LBLSERVICING
        '
        Me.LBLSERVICING.AutoSize = True
        Me.LBLSERVICING.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLSERVICING.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSERVICING.Location = New System.Drawing.Point(244, 9)
        Me.LBLSERVICING.Name = "LBLSERVICING"
        Me.LBLSERVICING.Size = New System.Drawing.Size(433, 56)
        Me.LBLSERVICING.TabIndex = 157
        Me.LBLSERVICING.Text = "SERVICE DETAILS"
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(153, 18)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(219, 20)
        Me.TXTID.TabIndex = 183
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(18, 25)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 182
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(153, 173)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(219, 20)
        Me.TextBox9.TabIndex = 181
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(582, 173)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(219, 20)
        Me.TextBox7.TabIndex = 180
        '
        'LBLCPHNO
        '
        Me.LBLCPHNO.AutoSize = True
        Me.LBLCPHNO.Location = New System.Drawing.Point(450, 180)
        Me.LBLCPHNO.Name = "LBLCPHNO"
        Me.LBLCPHNO.Size = New System.Drawing.Size(121, 13)
        Me.LBLCPHNO.TabIndex = 177
        Me.LBLCPHNO.Text = "ALTERNATE NUMBER"
        '
        'LBLCMNO
        '
        Me.LBLCMNO.AutoSize = True
        Me.LBLCMNO.Location = New System.Drawing.Point(18, 180)
        Me.LBLCMNO.Name = "LBLCMNO"
        Me.LBLCMNO.Size = New System.Drawing.Size(97, 13)
        Me.LBLCMNO.TabIndex = 176
        Me.LBLCMNO.Text = "MOBILE NUMBER"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(58, 99)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 174
        Me.LBLCNAME.Text = "NAME"
        '
        'LBLCADDR
        '
        Me.LBLCADDR.AutoSize = True
        Me.LBLCADDR.Location = New System.Drawing.Point(21, 91)
        Me.LBLCADDR.Name = "LBLCADDR"
        Me.LBLCADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLCADDR.TabIndex = 175
        Me.LBLCADDR.Text = "ADDRESS"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(153, 78)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(219, 70)
        Me.TextBox2.TabIndex = 179
        '
        'CMBCNAME
        '
        Me.CMBCNAME.FormattingEnabled = True
        Me.CMBCNAME.Location = New System.Drawing.Point(190, 91)
        Me.CMBCNAME.Name = "CMBCNAME"
        Me.CMBCNAME.Size = New System.Drawing.Size(219, 21)
        Me.CMBCNAME.TabIndex = 184
        Me.CMBCNAME.Text = "SELECT CUSTOMER NAME"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TXTID)
        Me.Panel1.Controls.Add(Me.LBLCID)
        Me.Panel1.Controls.Add(Me.TextBox9)
        Me.Panel1.Controls.Add(Me.TextBox7)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.LBLCPHNO)
        Me.Panel1.Controls.Add(Me.LBLCMNO)
        Me.Panel1.Controls.Add(Me.LBLCADDR)
        Me.Panel1.Location = New System.Drawing.Point(37, 137)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(814, 213)
        Me.Panel1.TabIndex = 185
        '
        'CHKINSTALL
        '
        Me.CHKINSTALL.AutoSize = True
        Me.CHKINSTALL.Location = New System.Drawing.Point(160, 576)
        Me.CHKINSTALL.Name = "CHKINSTALL"
        Me.CHKINSTALL.Size = New System.Drawing.Size(103, 17)
        Me.CHKINSTALL.TabIndex = 186
        Me.CHKINSTALL.Text = "INSTALLATION"
        Me.CHKINSTALL.UseVisualStyleBackColor = True
        '
        'TXT50000
        '
        Me.TXT50000.Location = New System.Drawing.Point(443, 576)
        Me.TXT50000.Name = "TXT50000"
        Me.TXT50000.Size = New System.Drawing.Size(121, 20)
        Me.TXT50000.TabIndex = 187
        Me.TXT50000.Text = "RS. 50000"
        '
        'SERVICING
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 716)
        Me.Controls.Add(Me.TXT50000)
        Me.Controls.Add(Me.CHKINSTALL)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CMBCNAME)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Controls.Add(Me.TXT15000)
        Me.Controls.Add(Me.TXT30000)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CHKREPLACE)
        Me.Controls.Add(Me.CHKCABLING)
        Me.Controls.Add(Me.CHKREPAIR)
        Me.Controls.Add(Me.TXTTE)
        Me.Controls.Add(Me.TXTRS)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLSERVICING)
        Me.Name = "SERVICING"
        Me.Text = "SERVICING FORM"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXT15000 As System.Windows.Forms.TextBox
    Friend WithEvents TXT30000 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CHKREPLACE As System.Windows.Forms.CheckBox
    Friend WithEvents CHKCABLING As System.Windows.Forms.CheckBox
    Friend WithEvents CHKREPAIR As System.Windows.Forms.CheckBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents TXTRS As System.Windows.Forms.TextBox
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents LBLSERVICING As System.Windows.Forms.Label
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents LBLCPHNO As System.Windows.Forms.Label
    Friend WithEvents LBLCMNO As System.Windows.Forms.Label
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents LBLCADDR As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents CMBCNAME As System.Windows.Forms.ComboBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CHKINSTALL As System.Windows.Forms.CheckBox
    Friend WithEvents TXT50000 As System.Windows.Forms.TextBox
End Class
