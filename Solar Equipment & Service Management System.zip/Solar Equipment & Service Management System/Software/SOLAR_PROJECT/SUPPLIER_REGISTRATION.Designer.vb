﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SUPPLIER_REGISTRATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNSEARCH = New System.Windows.Forms.Button
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.LBLCID = New System.Windows.Forms.Label
        Me.LBLSREG = New System.Windows.Forms.Label
        Me.TXTMNO = New System.Windows.Forms.TextBox
        Me.TXTEID = New System.Windows.Forms.TextBox
        Me.TXTANO = New System.Windows.Forms.TextBox
        Me.TXTADDR = New System.Windows.Forms.TextBox
        Me.TXTNAME = New System.Windows.Forms.TextBox
        Me.LBLFEMALE = New System.Windows.Forms.RadioButton
        Me.LBLMALE = New System.Windows.Forms.RadioButton
        Me.LBLGENDER = New System.Windows.Forms.Label
        Me.LBLEMAIL = New System.Windows.Forms.Label
        Me.LBLCPHNO = New System.Windows.Forms.Label
        Me.LBLCMNO = New System.Windows.Forms.Label
        Me.LBLCADDR = New System.Windows.Forms.Label
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNSEARCH
        '
        Me.BTNSEARCH.Location = New System.Drawing.Point(615, 420)
        Me.BTNSEARCH.Name = "BTNSEARCH"
        Me.BTNSEARCH.Size = New System.Drawing.Size(75, 23)
        Me.BTNSEARCH.TabIndex = 78
        Me.BTNSEARCH.Text = "SEARCH"
        Me.BTNSEARCH.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(775, 420)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 77
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(444, 420)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 76
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(270, 420)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 75
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(89, 420)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 74
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(202, 194)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(219, 20)
        Me.TXTID.TabIndex = 73
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(70, 201)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(74, 13)
        Me.LBLCID.TabIndex = 72
        Me.LBLCID.Text = "SUPPLIER ID"
        '
        'LBLSREG
        '
        Me.LBLSREG.AutoSize = True
        Me.LBLSREG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLSREG.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSREG.Location = New System.Drawing.Point(162, 45)
        Me.LBLSREG.Name = "LBLSREG"
        Me.LBLSREG.Size = New System.Drawing.Size(602, 56)
        Me.LBLSREG.TabIndex = 71
        Me.LBLSREG.Text = "SUPPLIER REGISTRATION"
        '
        'TXTMNO
        '
        Me.TXTMNO.Location = New System.Drawing.Point(202, 272)
        Me.TXTMNO.Name = "TXTMNO"
        Me.TXTMNO.Size = New System.Drawing.Size(219, 20)
        Me.TXTMNO.TabIndex = 70
        '
        'TXTEID
        '
        Me.TXTEID.Location = New System.Drawing.Point(631, 305)
        Me.TXTEID.Name = "TXTEID"
        Me.TXTEID.Size = New System.Drawing.Size(219, 20)
        Me.TXTEID.TabIndex = 69
        '
        'TXTANO
        '
        Me.TXTANO.Location = New System.Drawing.Point(631, 272)
        Me.TXTANO.Name = "TXTANO"
        Me.TXTANO.Size = New System.Drawing.Size(219, 20)
        Me.TXTANO.TabIndex = 68
        '
        'TXTADDR
        '
        Me.TXTADDR.Location = New System.Drawing.Point(631, 189)
        Me.TXTADDR.Multiline = True
        Me.TXTADDR.Name = "TXTADDR"
        Me.TXTADDR.Size = New System.Drawing.Size(219, 70)
        Me.TXTADDR.TabIndex = 67
        '
        'TXTNAME
        '
        Me.TXTNAME.Location = New System.Drawing.Point(202, 233)
        Me.TXTNAME.Name = "TXTNAME"
        Me.TXTNAME.Size = New System.Drawing.Size(219, 20)
        Me.TXTNAME.TabIndex = 66
        '
        'LBLFEMALE
        '
        Me.LBLFEMALE.AutoSize = True
        Me.LBLFEMALE.Location = New System.Drawing.Point(354, 304)
        Me.LBLFEMALE.Name = "LBLFEMALE"
        Me.LBLFEMALE.Size = New System.Drawing.Size(67, 17)
        Me.LBLFEMALE.TabIndex = 65
        Me.LBLFEMALE.TabStop = True
        Me.LBLFEMALE.Text = "FEMALE"
        Me.LBLFEMALE.UseVisualStyleBackColor = True
        '
        'LBLMALE
        '
        Me.LBLMALE.AutoSize = True
        Me.LBLMALE.Location = New System.Drawing.Point(202, 304)
        Me.LBLMALE.Name = "LBLMALE"
        Me.LBLMALE.Size = New System.Drawing.Size(54, 17)
        Me.LBLMALE.TabIndex = 64
        Me.LBLMALE.TabStop = True
        Me.LBLMALE.Text = "MALE"
        Me.LBLMALE.UseVisualStyleBackColor = True
        '
        'LBLGENDER
        '
        Me.LBLGENDER.AutoSize = True
        Me.LBLGENDER.Location = New System.Drawing.Point(70, 309)
        Me.LBLGENDER.Name = "LBLGENDER"
        Me.LBLGENDER.Size = New System.Drawing.Size(53, 13)
        Me.LBLGENDER.TabIndex = 63
        Me.LBLGENDER.Text = "GENDER"
        '
        'LBLEMAIL
        '
        Me.LBLEMAIL.AutoSize = True
        Me.LBLEMAIL.Location = New System.Drawing.Point(499, 308)
        Me.LBLEMAIL.Name = "LBLEMAIL"
        Me.LBLEMAIL.Size = New System.Drawing.Size(53, 13)
        Me.LBLEMAIL.TabIndex = 62
        Me.LBLEMAIL.Text = "EMAIL ID"
        '
        'LBLCPHNO
        '
        Me.LBLCPHNO.AutoSize = True
        Me.LBLCPHNO.Location = New System.Drawing.Point(499, 279)
        Me.LBLCPHNO.Name = "LBLCPHNO"
        Me.LBLCPHNO.Size = New System.Drawing.Size(121, 13)
        Me.LBLCPHNO.TabIndex = 61
        Me.LBLCPHNO.Text = "ALTERNATE NUMBER"
        '
        'LBLCMNO
        '
        Me.LBLCMNO.AutoSize = True
        Me.LBLCMNO.Location = New System.Drawing.Point(67, 279)
        Me.LBLCMNO.Name = "LBLCMNO"
        Me.LBLCMNO.Size = New System.Drawing.Size(97, 13)
        Me.LBLCMNO.TabIndex = 60
        Me.LBLCMNO.Text = "MOBILE NUMBER"
        '
        'LBLCADDR
        '
        Me.LBLCADDR.AutoSize = True
        Me.LBLCADDR.Location = New System.Drawing.Point(499, 194)
        Me.LBLCADDR.Name = "LBLCADDR"
        Me.LBLCADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLCADDR.TabIndex = 59
        Me.LBLCADDR.Text = "ADDRESS"
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(67, 240)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 58
        Me.LBLCNAME.Text = "NAME"
        '
        'SUPPLIER_REGISTRATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(916, 481)
        Me.Controls.Add(Me.BTNSEARCH)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.TXTID)
        Me.Controls.Add(Me.LBLCID)
        Me.Controls.Add(Me.LBLSREG)
        Me.Controls.Add(Me.TXTMNO)
        Me.Controls.Add(Me.TXTEID)
        Me.Controls.Add(Me.TXTANO)
        Me.Controls.Add(Me.TXTADDR)
        Me.Controls.Add(Me.TXTNAME)
        Me.Controls.Add(Me.LBLFEMALE)
        Me.Controls.Add(Me.LBLMALE)
        Me.Controls.Add(Me.LBLGENDER)
        Me.Controls.Add(Me.LBLEMAIL)
        Me.Controls.Add(Me.LBLCPHNO)
        Me.Controls.Add(Me.LBLCMNO)
        Me.Controls.Add(Me.LBLCADDR)
        Me.Controls.Add(Me.LBLCNAME)
        Me.Name = "SUPPLIER_REGISTRATION"
        Me.Text = "SUPPLIER REGISTRATION FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNSEARCH As System.Windows.Forms.Button
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents LBLSREG As System.Windows.Forms.Label
    Friend WithEvents TXTMNO As System.Windows.Forms.TextBox
    Friend WithEvents TXTEID As System.Windows.Forms.TextBox
    Friend WithEvents TXTANO As System.Windows.Forms.TextBox
    Friend WithEvents TXTADDR As System.Windows.Forms.TextBox
    Friend WithEvents TXTNAME As System.Windows.Forms.TextBox
    Friend WithEvents LBLFEMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLGENDER As System.Windows.Forms.Label
    Friend WithEvents LBLEMAIL As System.Windows.Forms.Label
    Friend WithEvents LBLCPHNO As System.Windows.Forms.Label
    Friend WithEvents LBLCMNO As System.Windows.Forms.Label
    Friend WithEvents LBLCADDR As System.Windows.Forms.Label
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
End Class
