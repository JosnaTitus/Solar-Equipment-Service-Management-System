﻿Public Class CUSTOMER_ORDER

End Class