﻿Public Class SUPPLIER_REGISTRATION

    Private Sub SUPPLIER_REGISTRATION_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class