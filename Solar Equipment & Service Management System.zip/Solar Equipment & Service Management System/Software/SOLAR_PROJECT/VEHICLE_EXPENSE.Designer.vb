﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VEHICLE_EXPENSE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLVEXPENSE = New System.Windows.Forms.Label
        Me.LBLVID = New System.Windows.Forms.Label
        Me.LBLFTYPE = New System.Windows.Forms.Label
        Me.LBLVREGNO = New System.Windows.Forms.Label
        Me.LBLVNAME = New System.Windows.Forms.Label
        Me.TXTVID = New System.Windows.Forms.TextBox
        Me.TXTFTYPE = New System.Windows.Forms.TextBox
        Me.TXTVNAME = New System.Windows.Forms.TextBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.CMBVREG = New System.Windows.Forms.ComboBox
        Me.LBLTE = New System.Windows.Forms.Label
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LBLVEXPENSE
        '
        Me.LBLVEXPENSE.AutoSize = True
        Me.LBLVEXPENSE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLVEXPENSE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLVEXPENSE.Location = New System.Drawing.Point(75, 9)
        Me.LBLVEXPENSE.Name = "LBLVEXPENSE"
        Me.LBLVEXPENSE.Size = New System.Drawing.Size(659, 56)
        Me.LBLVEXPENSE.TabIndex = 119
        Me.LBLVEXPENSE.Text = "VEHICLE EXPENSE DETAILS"
        '
        'LBLVID
        '
        Me.LBLVID.AutoSize = True
        Me.LBLVID.Location = New System.Drawing.Point(21, 32)
        Me.LBLVID.Name = "LBLVID"
        Me.LBLVID.Size = New System.Drawing.Size(66, 13)
        Me.LBLVID.TabIndex = 120
        Me.LBLVID.Text = "VEHICLE ID"
        '
        'LBLFTYPE
        '
        Me.LBLFTYPE.AutoSize = True
        Me.LBLFTYPE.Location = New System.Drawing.Point(22, 159)
        Me.LBLFTYPE.Name = "LBLFTYPE"
        Me.LBLFTYPE.Size = New System.Drawing.Size(65, 13)
        Me.LBLFTYPE.TabIndex = 122
        Me.LBLFTYPE.Text = "FUEL TYPE"
        '
        'LBLVREGNO
        '
        Me.LBLVREGNO.AutoSize = True
        Me.LBLVREGNO.Location = New System.Drawing.Point(175, 102)
        Me.LBLVREGNO.Name = "LBLVREGNO"
        Me.LBLVREGNO.Size = New System.Drawing.Size(114, 13)
        Me.LBLVREGNO.TabIndex = 124
        Me.LBLVREGNO.Text = "REGISTERATION NO"
        '
        'LBLVNAME
        '
        Me.LBLVNAME.AutoSize = True
        Me.LBLVNAME.Location = New System.Drawing.Point(21, 97)
        Me.LBLVNAME.Name = "LBLVNAME"
        Me.LBLVNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLVNAME.TabIndex = 125
        Me.LBLVNAME.Text = "NAME"
        '
        'TXTVID
        '
        Me.TXTVID.Location = New System.Drawing.Point(308, 25)
        Me.TXTVID.Name = "TXTVID"
        Me.TXTVID.Size = New System.Drawing.Size(120, 20)
        Me.TXTVID.TabIndex = 126
        '
        'TXTFTYPE
        '
        Me.TXTFTYPE.Location = New System.Drawing.Point(308, 159)
        Me.TXTFTYPE.Name = "TXTFTYPE"
        Me.TXTFTYPE.Size = New System.Drawing.Size(120, 20)
        Me.TXTFTYPE.TabIndex = 130
        '
        'TXTVNAME
        '
        Me.TXTVNAME.Location = New System.Drawing.Point(308, 90)
        Me.TXTVNAME.Name = "TXTVNAME"
        Me.TXTVNAME.Size = New System.Drawing.Size(120, 20)
        Me.TXTVNAME.TabIndex = 131
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(605, 427)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 135
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(461, 427)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 134
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(287, 427)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 133
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(106, 427)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 132
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'CMBVREG
        '
        Me.CMBVREG.FormattingEnabled = True
        Me.CMBVREG.Location = New System.Drawing.Point(461, 102)
        Me.CMBVREG.Name = "CMBVREG"
        Me.CMBVREG.Size = New System.Drawing.Size(121, 21)
        Me.CMBVREG.TabIndex = 136
        '
        'LBLTE
        '
        Me.LBLTE.AutoSize = True
        Me.LBLTE.Location = New System.Drawing.Point(176, 368)
        Me.LBLTE.Name = "LBLTE"
        Me.LBLTE.Size = New System.Drawing.Size(95, 13)
        Me.LBLTE.TabIndex = 137
        Me.LBLTE.Text = "TOTAL EXPENSE"
        '
        'TXTTE
        '
        Me.TXTTE.Location = New System.Drawing.Point(462, 368)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(120, 20)
        Me.TXTTE.TabIndex = 138
        Me.TXTTE.Text = "RS."
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TXTVNAME)
        Me.Panel1.Controls.Add(Me.TXTFTYPE)
        Me.Panel1.Controls.Add(Me.TXTVID)
        Me.Panel1.Controls.Add(Me.LBLVNAME)
        Me.Panel1.Controls.Add(Me.LBLFTYPE)
        Me.Panel1.Controls.Add(Me.LBLVID)
        Me.Panel1.Location = New System.Drawing.Point(154, 149)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(464, 197)
        Me.Panel1.TabIndex = 139
        '
        'VEHICLE_EXPENSE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 493)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TXTTE)
        Me.Controls.Add(Me.LBLTE)
        Me.Controls.Add(Me.CMBVREG)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLVREGNO)
        Me.Controls.Add(Me.LBLVEXPENSE)
        Me.Name = "VEHICLE_EXPENSE"
        Me.Text = "VEHICLE EXPENSE FORM"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLVEXPENSE As System.Windows.Forms.Label
    Friend WithEvents LBLVID As System.Windows.Forms.Label
    Friend WithEvents LBLFTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLVREGNO As System.Windows.Forms.Label
    Friend WithEvents LBLVNAME As System.Windows.Forms.Label
    Friend WithEvents TXTVID As System.Windows.Forms.TextBox
    Friend WithEvents TXTFTYPE As System.Windows.Forms.TextBox
    Friend WithEvents TXTVNAME As System.Windows.Forms.TextBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents CMBVREG As System.Windows.Forms.ComboBox
    Friend WithEvents LBLTE As System.Windows.Forms.Label
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
