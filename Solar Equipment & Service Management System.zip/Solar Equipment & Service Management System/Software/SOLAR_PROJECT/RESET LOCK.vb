﻿Public Class RESET_LOCK

    Private Sub CMBNAME_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CMBNAME.SelectedIndexChanged

    End Sub
End Class