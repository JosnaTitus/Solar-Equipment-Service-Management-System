﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SUPPLIER_PAYMENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.TXTINVOICE = New System.Windows.Forms.TextBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.RADCASH = New System.Windows.Forms.RadioButton
        Me.RADCHEQUE = New System.Windows.Forms.RadioButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TXTPNO = New System.Windows.Forms.TextBox
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.LBLSNAME = New System.Windows.Forms.Label
        Me.LBLINVOICE = New System.Windows.Forms.Label
        Me.LBLPID = New System.Windows.Forms.Label
        Me.TXTAMT = New System.Windows.Forms.TextBox
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.LBLSPAYMENT = New System.Windows.Forms.Label
        Me.CMBDATE = New System.Windows.Forms.ComboBox
        Me.CMBSNAME = New System.Windows.Forms.ComboBox
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(657, 602)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 105
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'TXTINVOICE
        '
        Me.TXTINVOICE.Location = New System.Drawing.Point(558, 70)
        Me.TXTINVOICE.Name = "TXTINVOICE"
        Me.TXTINVOICE.Size = New System.Drawing.Size(121, 20)
        Me.TXTINVOICE.TabIndex = 12
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(62, 205)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(790, 150)
        Me.DataGridView1.TabIndex = 98
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(75, 385)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 95
        Me.LBLAMT.Text = "AMOUNT"
        '
        'RADCASH
        '
        Me.RADCASH.AutoSize = True
        Me.RADCASH.Location = New System.Drawing.Point(478, 386)
        Me.RADCASH.Name = "RADCASH"
        Me.RADCASH.Size = New System.Drawing.Size(54, 17)
        Me.RADCASH.TabIndex = 96
        Me.RADCASH.TabStop = True
        Me.RADCASH.Text = "CASH"
        Me.RADCASH.UseVisualStyleBackColor = True
        '
        'RADCHEQUE
        '
        Me.RADCHEQUE.AutoSize = True
        Me.RADCHEQUE.Location = New System.Drawing.Point(685, 388)
        Me.RADCHEQUE.Name = "RADCHEQUE"
        Me.RADCHEQUE.Size = New System.Drawing.Size(70, 17)
        Me.RADCHEQUE.TabIndex = 97
        Me.RADCHEQUE.TabStop = True
        Me.RADCHEQUE.Text = "CHEQUE"
        Me.RADCHEQUE.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CMBSNAME)
        Me.Panel1.Controls.Add(Me.CMBDATE)
        Me.Panel1.Controls.Add(Me.TXTINVOICE)
        Me.Panel1.Controls.Add(Me.TXTPNO)
        Me.Panel1.Controls.Add(Me.LBLDATE)
        Me.Panel1.Controls.Add(Me.LBLSNAME)
        Me.Panel1.Controls.Add(Me.LBLINVOICE)
        Me.Panel1.Controls.Add(Me.LBLPID)
        Me.Panel1.Location = New System.Drawing.Point(62, 89)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(790, 110)
        Me.Panel1.TabIndex = 99
        '
        'TXTPNO
        '
        Me.TXTPNO.Location = New System.Drawing.Point(184, 20)
        Me.TXTPNO.Name = "TXTPNO"
        Me.TXTPNO.Size = New System.Drawing.Size(121, 20)
        Me.TXTPNO.TabIndex = 10
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(27, 77)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(91, 13)
        Me.LBLDATE.TabIndex = 6
        Me.LBLDATE.Text = "PAYMENT DATE"
        '
        'LBLSNAME
        '
        Me.LBLSNAME.AutoSize = True
        Me.LBLSNAME.Location = New System.Drawing.Point(427, 20)
        Me.LBLSNAME.Name = "LBLSNAME"
        Me.LBLSNAME.Size = New System.Drawing.Size(94, 13)
        Me.LBLSNAME.TabIndex = 5
        Me.LBLSNAME.Text = "SUPPLIER NAME"
        '
        'LBLINVOICE
        '
        Me.LBLINVOICE.AutoSize = True
        Me.LBLINVOICE.Location = New System.Drawing.Point(427, 77)
        Me.LBLINVOICE.Name = "LBLINVOICE"
        Me.LBLINVOICE.Size = New System.Drawing.Size(69, 13)
        Me.LBLINVOICE.TabIndex = 4
        Me.LBLINVOICE.Text = "INVOICE NO"
        '
        'LBLPID
        '
        Me.LBLPID.AutoSize = True
        Me.LBLPID.Location = New System.Drawing.Point(27, 20)
        Me.LBLPID.Name = "LBLPID"
        Me.LBLPID.Size = New System.Drawing.Size(78, 13)
        Me.LBLPID.TabIndex = 0
        Me.LBLPID.Text = "PAYMENT NO"
        '
        'TXTAMT
        '
        Me.TXTAMT.Location = New System.Drawing.Point(232, 385)
        Me.TXTAMT.Name = "TXTAMT"
        Me.TXTAMT.Size = New System.Drawing.Size(100, 20)
        Me.TXTAMT.TabIndex = 100
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(513, 602)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 104
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(339, 602)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 103
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(158, 602)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 102
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(62, 425)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(790, 150)
        Me.DataGridView2.TabIndex = 101
        '
        'LBLSPAYMENT
        '
        Me.LBLSPAYMENT.AutoSize = True
        Me.LBLSPAYMENT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLSPAYMENT.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSPAYMENT.Location = New System.Drawing.Point(92, 20)
        Me.LBLSPAYMENT.Name = "LBLSPAYMENT"
        Me.LBLSPAYMENT.Size = New System.Drawing.Size(694, 56)
        Me.LBLSPAYMENT.TabIndex = 106
        Me.LBLSPAYMENT.Text = "SUPPLIER PAYMENT DETAILS"
        '
        'CMBDATE
        '
        Me.CMBDATE.FormattingEnabled = True
        Me.CMBDATE.Location = New System.Drawing.Point(184, 77)
        Me.CMBDATE.Name = "CMBDATE"
        Me.CMBDATE.Size = New System.Drawing.Size(121, 21)
        Me.CMBDATE.TabIndex = 14
        '
        'CMBSNAME
        '
        Me.CMBSNAME.FormattingEnabled = True
        Me.CMBSNAME.Location = New System.Drawing.Point(558, 17)
        Me.CMBSNAME.Name = "CMBSNAME"
        Me.CMBSNAME.Size = New System.Drawing.Size(121, 21)
        Me.CMBSNAME.TabIndex = 15
        '
        'SUPPLIER_PAYMENT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(878, 651)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.RADCASH)
        Me.Controls.Add(Me.RADCHEQUE)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TXTAMT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.LBLSPAYMENT)
        Me.Name = "SUPPLIER_PAYMENT"
        Me.Text = "SUPPLIER PAYMENT FORM"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents TXTINVOICE As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents RADCASH As System.Windows.Forms.RadioButton
    Friend WithEvents RADCHEQUE As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TXTPNO As System.Windows.Forms.TextBox
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents LBLSNAME As System.Windows.Forms.Label
    Friend WithEvents LBLINVOICE As System.Windows.Forms.Label
    Friend WithEvents LBLPID As System.Windows.Forms.Label
    Friend WithEvents TXTAMT As System.Windows.Forms.TextBox
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents LBLSPAYMENT As System.Windows.Forms.Label
    Friend WithEvents CMBSNAME As System.Windows.Forms.ComboBox
    Friend WithEvents CMBDATE As System.Windows.Forms.ComboBox
End Class
