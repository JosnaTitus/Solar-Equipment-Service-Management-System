﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VEHICLE_DETAILS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTVNAME = New System.Windows.Forms.TextBox
        Me.TXTFTYPE = New System.Windows.Forms.TextBox
        Me.TXTCAP = New System.Windows.Forms.TextBox
        Me.TXTVREGNO = New System.Windows.Forms.TextBox
        Me.TXTMYEAR = New System.Windows.Forms.TextBox
        Me.TXTVID = New System.Windows.Forms.TextBox
        Me.LBLVNAME = New System.Windows.Forms.Label
        Me.LBLVREGNO = New System.Windows.Forms.Label
        Me.LBLMYEAR = New System.Windows.Forms.Label
        Me.LBLFTYPE = New System.Windows.Forms.Label
        Me.LBLCAP = New System.Windows.Forms.Label
        Me.LBLVID = New System.Windows.Forms.Label
        Me.LBLVEHICLE = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(660, 427)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 152
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(516, 427)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 151
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(342, 427)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 150
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(161, 427)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 149
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTVNAME
        '
        Me.TXTVNAME.Location = New System.Drawing.Point(516, 138)
        Me.TXTVNAME.Name = "TXTVNAME"
        Me.TXTVNAME.Size = New System.Drawing.Size(100, 20)
        Me.TXTVNAME.TabIndex = 148
        '
        'TXTFTYPE
        '
        Me.TXTFTYPE.Location = New System.Drawing.Point(516, 302)
        Me.TXTFTYPE.Name = "TXTFTYPE"
        Me.TXTFTYPE.Size = New System.Drawing.Size(100, 20)
        Me.TXTFTYPE.TabIndex = 147
        '
        'TXTCAP
        '
        Me.TXTCAP.Location = New System.Drawing.Point(516, 353)
        Me.TXTCAP.Name = "TXTCAP"
        Me.TXTCAP.Size = New System.Drawing.Size(100, 20)
        Me.TXTCAP.TabIndex = 146
        '
        'TXTVREGNO
        '
        Me.TXTVREGNO.Location = New System.Drawing.Point(516, 192)
        Me.TXTVREGNO.Name = "TXTVREGNO"
        Me.TXTVREGNO.Size = New System.Drawing.Size(100, 20)
        Me.TXTVREGNO.TabIndex = 145
        '
        'TXTMYEAR
        '
        Me.TXTMYEAR.Location = New System.Drawing.Point(516, 246)
        Me.TXTMYEAR.Name = "TXTMYEAR"
        Me.TXTMYEAR.Size = New System.Drawing.Size(100, 20)
        Me.TXTMYEAR.TabIndex = 144
        '
        'TXTVID
        '
        Me.TXTVID.Location = New System.Drawing.Point(516, 90)
        Me.TXTVID.Name = "TXTVID"
        Me.TXTVID.Size = New System.Drawing.Size(100, 20)
        Me.TXTVID.TabIndex = 143
        '
        'LBLVNAME
        '
        Me.LBLVNAME.AutoSize = True
        Me.LBLVNAME.Location = New System.Drawing.Point(236, 145)
        Me.LBLVNAME.Name = "LBLVNAME"
        Me.LBLVNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLVNAME.TabIndex = 142
        Me.LBLVNAME.Text = "NAME"
        '
        'LBLVREGNO
        '
        Me.LBLVREGNO.AutoSize = True
        Me.LBLVREGNO.Location = New System.Drawing.Point(236, 199)
        Me.LBLVREGNO.Name = "LBLVREGNO"
        Me.LBLVREGNO.Size = New System.Drawing.Size(114, 13)
        Me.LBLVREGNO.TabIndex = 141
        Me.LBLVREGNO.Text = "REGISTERATION NO"
        '
        'LBLMYEAR
        '
        Me.LBLMYEAR.AutoSize = True
        Me.LBLMYEAR.Location = New System.Drawing.Point(236, 253)
        Me.LBLMYEAR.Name = "LBLMYEAR"
        Me.LBLMYEAR.Size = New System.Drawing.Size(121, 13)
        Me.LBLMYEAR.TabIndex = 140
        Me.LBLMYEAR.Text = "MANUFACTURE YEAR"
        '
        'LBLFTYPE
        '
        Me.LBLFTYPE.AutoSize = True
        Me.LBLFTYPE.Location = New System.Drawing.Point(236, 309)
        Me.LBLFTYPE.Name = "LBLFTYPE"
        Me.LBLFTYPE.Size = New System.Drawing.Size(65, 13)
        Me.LBLFTYPE.TabIndex = 139
        Me.LBLFTYPE.Text = "FUEL TYPE"
        '
        'LBLCAP
        '
        Me.LBLCAP.AutoSize = True
        Me.LBLCAP.Location = New System.Drawing.Point(236, 360)
        Me.LBLCAP.Name = "LBLCAP"
        Me.LBLCAP.Size = New System.Drawing.Size(59, 13)
        Me.LBLCAP.TabIndex = 138
        Me.LBLCAP.Text = "CAPACITY"
        '
        'LBLVID
        '
        Me.LBLVID.AutoSize = True
        Me.LBLVID.Location = New System.Drawing.Point(236, 97)
        Me.LBLVID.Name = "LBLVID"
        Me.LBLVID.Size = New System.Drawing.Size(66, 13)
        Me.LBLVID.TabIndex = 137
        Me.LBLVID.Text = "VEHICLE ID"
        '
        'LBLVEHICLE
        '
        Me.LBLVEHICLE.AutoSize = True
        Me.LBLVEHICLE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLVEHICLE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLVEHICLE.Location = New System.Drawing.Point(204, -22)
        Me.LBLVEHICLE.Name = "LBLVEHICLE"
        Me.LBLVEHICLE.Size = New System.Drawing.Size(432, 56)
        Me.LBLVEHICLE.TabIndex = 136
        Me.LBLVEHICLE.Text = "VEHICLE DETAILS"
        '
        'VEHICLE_DETAILS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(896, 428)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.TXTVNAME)
        Me.Controls.Add(Me.TXTFTYPE)
        Me.Controls.Add(Me.TXTCAP)
        Me.Controls.Add(Me.TXTVREGNO)
        Me.Controls.Add(Me.TXTMYEAR)
        Me.Controls.Add(Me.TXTVID)
        Me.Controls.Add(Me.LBLVNAME)
        Me.Controls.Add(Me.LBLVREGNO)
        Me.Controls.Add(Me.LBLMYEAR)
        Me.Controls.Add(Me.LBLFTYPE)
        Me.Controls.Add(Me.LBLCAP)
        Me.Controls.Add(Me.LBLVID)
        Me.Controls.Add(Me.LBLVEHICLE)
        Me.Name = "VEHICLE_DETAILS"
        Me.Text = "VEHICLE DETAILS FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTVNAME As System.Windows.Forms.TextBox
    Friend WithEvents TXTFTYPE As System.Windows.Forms.TextBox
    Friend WithEvents TXTCAP As System.Windows.Forms.TextBox
    Friend WithEvents TXTVREGNO As System.Windows.Forms.TextBox
    Friend WithEvents TXTMYEAR As System.Windows.Forms.TextBox
    Friend WithEvents TXTVID As System.Windows.Forms.TextBox
    Friend WithEvents LBLVNAME As System.Windows.Forms.Label
    Friend WithEvents LBLVREGNO As System.Windows.Forms.Label
    Friend WithEvents LBLMYEAR As System.Windows.Forms.Label
    Friend WithEvents LBLFTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLCAP As System.Windows.Forms.Label
    Friend WithEvents LBLVID As System.Windows.Forms.Label
    Friend WithEvents LBLVEHICLE As System.Windows.Forms.Label
End Class
