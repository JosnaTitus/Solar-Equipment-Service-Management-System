﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRMLOGIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNLOGIN = New System.Windows.Forms.Button
        Me.LBLPASS = New System.Windows.Forms.Label
        Me.LBLNAME = New System.Windows.Forms.Label
        Me.TXTPASS = New System.Windows.Forms.TextBox
        Me.LBLLOGIN = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.CMBNAME = New System.Windows.Forms.ComboBox
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(536, 312)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 142
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNLOGIN
        '
        Me.BTNLOGIN.Location = New System.Drawing.Point(212, 312)
        Me.BTNLOGIN.Name = "BTNLOGIN"
        Me.BTNLOGIN.Size = New System.Drawing.Size(75, 23)
        Me.BTNLOGIN.TabIndex = 141
        Me.BTNLOGIN.Text = "LOGIN"
        Me.BTNLOGIN.UseVisualStyleBackColor = True
        '
        'LBLPASS
        '
        Me.LBLPASS.AutoSize = True
        Me.LBLPASS.Location = New System.Drawing.Point(51, 120)
        Me.LBLPASS.Name = "LBLPASS"
        Me.LBLPASS.Size = New System.Drawing.Size(70, 13)
        Me.LBLPASS.TabIndex = 140
        Me.LBLPASS.Text = "PASSWORD"
        '
        'LBLNAME
        '
        Me.LBLNAME.AutoSize = True
        Me.LBLNAME.Location = New System.Drawing.Point(51, 29)
        Me.LBLNAME.Name = "LBLNAME"
        Me.LBLNAME.Size = New System.Drawing.Size(71, 13)
        Me.LBLNAME.TabIndex = 139
        Me.LBLNAME.Text = "USER NAME"
        '
        'TXTPASS
        '
        Me.TXTPASS.Location = New System.Drawing.Point(179, 113)
        Me.TXTPASS.Name = "TXTPASS"
        Me.TXTPASS.Size = New System.Drawing.Size(121, 20)
        Me.TXTPASS.TabIndex = 138
        '
        'LBLLOGIN
        '
        Me.LBLLOGIN.AutoSize = True
        Me.LBLLOGIN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLLOGIN.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLLOGIN.Location = New System.Drawing.Point(256, 9)
        Me.LBLLOGIN.Name = "LBLLOGIN"
        Me.LBLLOGIN.Size = New System.Drawing.Size(301, 56)
        Me.LBLLOGIN.TabIndex = 136
        Me.LBLLOGIN.Text = "LOGIN FORM"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CMBNAME)
        Me.Panel1.Controls.Add(Me.LBLPASS)
        Me.Panel1.Controls.Add(Me.LBLNAME)
        Me.Panel1.Controls.Add(Me.TXTPASS)
        Me.Panel1.Location = New System.Drawing.Point(238, 103)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(346, 171)
        Me.Panel1.TabIndex = 143
        '
        'CMBNAME
        '
        Me.CMBNAME.FormattingEnabled = True
        Me.CMBNAME.Location = New System.Drawing.Point(179, 21)
        Me.CMBNAME.Name = "CMBNAME"
        Me.CMBNAME.Size = New System.Drawing.Size(121, 21)
        Me.CMBNAME.TabIndex = 141
        Me.CMBNAME.Text = "SELECT NAME"
        '
        'FRMLOGIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 378)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNLOGIN)
        Me.Controls.Add(Me.LBLLOGIN)
        Me.Name = "FRMLOGIN"
        Me.Text = "LOGIN FORM"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNLOGIN As System.Windows.Forms.Button
    Friend WithEvents LBLPASS As System.Windows.Forms.Label
    Friend WithEvents LBLNAME As System.Windows.Forms.Label
    Friend WithEvents TXTPASS As System.Windows.Forms.TextBox
    Friend WithEvents LBLLOGIN As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CMBNAME As System.Windows.Forms.ComboBox
End Class
