﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VEHICLE_MAINTENANCE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.LBLAMT = New System.Windows.Forms.Label
        Me.CMBVREG = New System.Windows.Forms.ComboBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.LBLVMAINTENANCE = New System.Windows.Forms.Label
        Me.TXTVNAME = New System.Windows.Forms.TextBox
        Me.LBLVREGNO = New System.Windows.Forms.Label
        Me.TXTVID = New System.Windows.Forms.TextBox
        Me.LBLFTYPE = New System.Windows.Forms.Label
        Me.LBLVID = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TXTFTYPE = New System.Windows.Forms.TextBox
        Me.LBLVNAME = New System.Windows.Forms.Label
        Me.CHKREGULAR = New System.Windows.Forms.CheckBox
        Me.CHKREPAIR = New System.Windows.Forms.CheckBox
        Me.CHKCHANGE = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TXT30000 = New System.Windows.Forms.TextBox
        Me.TXT15000 = New System.Windows.Forms.TextBox
        Me.TXT25000 = New System.Windows.Forms.TextBox
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TXTTE
        '
        Me.TXTTE.Enabled = False
        Me.TXTTE.Location = New System.Drawing.Point(503, 593)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(120, 20)
        Me.TXTTE.TabIndex = 148
        Me.TXTTE.Text = "RS."
        '
        'LBLAMT
        '
        Me.LBLAMT.AutoSize = True
        Me.LBLAMT.Location = New System.Drawing.Point(217, 593)
        Me.LBLAMT.Name = "LBLAMT"
        Me.LBLAMT.Size = New System.Drawing.Size(54, 13)
        Me.LBLAMT.TabIndex = 147
        Me.LBLAMT.Text = "AMOUNT"
        '
        'CMBVREG
        '
        Me.CMBVREG.FormattingEnabled = True
        Me.CMBVREG.Location = New System.Drawing.Point(502, 120)
        Me.CMBVREG.Name = "CMBVREG"
        Me.CMBVREG.Size = New System.Drawing.Size(121, 21)
        Me.CMBVREG.TabIndex = 146
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(646, 650)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 145
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(502, 650)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 144
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(328, 650)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 143
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(147, 650)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 142
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'LBLVMAINTENANCE
        '
        Me.LBLVMAINTENANCE.AutoSize = True
        Me.LBLVMAINTENANCE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLVMAINTENANCE.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLVMAINTENANCE.Location = New System.Drawing.Point(116, 27)
        Me.LBLVMAINTENANCE.Name = "LBLVMAINTENANCE"
        Me.LBLVMAINTENANCE.Size = New System.Drawing.Size(781, 56)
        Me.LBLVMAINTENANCE.TabIndex = 140
        Me.LBLVMAINTENANCE.Text = "VEHICLE MAINTENANCE DETAILS"
        '
        'TXTVNAME
        '
        Me.TXTVNAME.Location = New System.Drawing.Point(308, 90)
        Me.TXTVNAME.Name = "TXTVNAME"
        Me.TXTVNAME.Size = New System.Drawing.Size(120, 20)
        Me.TXTVNAME.TabIndex = 131
        '
        'LBLVREGNO
        '
        Me.LBLVREGNO.AutoSize = True
        Me.LBLVREGNO.Location = New System.Drawing.Point(216, 120)
        Me.LBLVREGNO.Name = "LBLVREGNO"
        Me.LBLVREGNO.Size = New System.Drawing.Size(114, 13)
        Me.LBLVREGNO.TabIndex = 141
        Me.LBLVREGNO.Text = "REGISTERATION NO"
        '
        'TXTVID
        '
        Me.TXTVID.Location = New System.Drawing.Point(308, 25)
        Me.TXTVID.Name = "TXTVID"
        Me.TXTVID.Size = New System.Drawing.Size(120, 20)
        Me.TXTVID.TabIndex = 126
        '
        'LBLFTYPE
        '
        Me.LBLFTYPE.AutoSize = True
        Me.LBLFTYPE.Location = New System.Drawing.Point(22, 159)
        Me.LBLFTYPE.Name = "LBLFTYPE"
        Me.LBLFTYPE.Size = New System.Drawing.Size(65, 13)
        Me.LBLFTYPE.TabIndex = 122
        Me.LBLFTYPE.Text = "FUEL TYPE"
        '
        'LBLVID
        '
        Me.LBLVID.AutoSize = True
        Me.LBLVID.Location = New System.Drawing.Point(21, 32)
        Me.LBLVID.Name = "LBLVID"
        Me.LBLVID.Size = New System.Drawing.Size(66, 13)
        Me.LBLVID.TabIndex = 120
        Me.LBLVID.Text = "VEHICLE ID"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TXTVNAME)
        Me.Panel1.Controls.Add(Me.TXTFTYPE)
        Me.Panel1.Controls.Add(Me.TXTVID)
        Me.Panel1.Controls.Add(Me.LBLVNAME)
        Me.Panel1.Controls.Add(Me.LBLFTYPE)
        Me.Panel1.Controls.Add(Me.LBLVID)
        Me.Panel1.Location = New System.Drawing.Point(195, 167)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(464, 197)
        Me.Panel1.TabIndex = 149
        '
        'TXTFTYPE
        '
        Me.TXTFTYPE.Location = New System.Drawing.Point(308, 159)
        Me.TXTFTYPE.Name = "TXTFTYPE"
        Me.TXTFTYPE.Size = New System.Drawing.Size(120, 20)
        Me.TXTFTYPE.TabIndex = 130
        '
        'LBLVNAME
        '
        Me.LBLVNAME.AutoSize = True
        Me.LBLVNAME.Location = New System.Drawing.Point(21, 97)
        Me.LBLVNAME.Name = "LBLVNAME"
        Me.LBLVNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLVNAME.TabIndex = 125
        Me.LBLVNAME.Text = "NAME"
        '
        'CHKREGULAR
        '
        Me.CHKREGULAR.AutoSize = True
        Me.CHKREGULAR.Location = New System.Drawing.Point(219, 453)
        Me.CHKREGULAR.Name = "CHKREGULAR"
        Me.CHKREGULAR.Size = New System.Drawing.Size(127, 17)
        Me.CHKREGULAR.TabIndex = 150
        Me.CHKREGULAR.Text = "REGULAR SERVICE"
        Me.CHKREGULAR.UseVisualStyleBackColor = True
        '
        'CHKREPAIR
        '
        Me.CHKREPAIR.AutoSize = True
        Me.CHKREPAIR.Location = New System.Drawing.Point(219, 499)
        Me.CHKREPAIR.Name = "CHKREPAIR"
        Me.CHKREPAIR.Size = New System.Drawing.Size(85, 17)
        Me.CHKREPAIR.TabIndex = 151
        Me.CHKREPAIR.Text = "REPAIRING"
        Me.CHKREPAIR.UseVisualStyleBackColor = True
        '
        'CHKCHANGE
        '
        Me.CHKCHANGE.AutoSize = True
        Me.CHKCHANGE.Location = New System.Drawing.Point(219, 545)
        Me.CHKCHANGE.Name = "CHKCHANGE"
        Me.CHKCHANGE.Size = New System.Drawing.Size(110, 17)
        Me.CHKCHANGE.TabIndex = 152
        Me.CHKCHANGE.Text = "PARTS CHANGE"
        Me.CHKCHANGE.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(213, 396)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(429, 31)
        Me.Label1.TabIndex = 153
        Me.Label1.Text = "SERVICE PROVIDED DETAILS"
        '
        'TXT30000
        '
        Me.TXT30000.Enabled = False
        Me.TXT30000.Location = New System.Drawing.Point(502, 450)
        Me.TXT30000.Name = "TXT30000"
        Me.TXT30000.Size = New System.Drawing.Size(121, 20)
        Me.TXT30000.TabIndex = 154
        Me.TXT30000.Text = "RS. 30000"
        '
        'TXT15000
        '
        Me.TXT15000.Enabled = False
        Me.TXT15000.Location = New System.Drawing.Point(502, 496)
        Me.TXT15000.Name = "TXT15000"
        Me.TXT15000.Size = New System.Drawing.Size(121, 20)
        Me.TXT15000.TabIndex = 155
        Me.TXT15000.Text = "RS. 15000"
        '
        'TXT25000
        '
        Me.TXT25000.Enabled = False
        Me.TXT25000.Location = New System.Drawing.Point(502, 545)
        Me.TXT25000.Name = "TXT25000"
        Me.TXT25000.Size = New System.Drawing.Size(121, 20)
        Me.TXT25000.TabIndex = 156
        Me.TXT25000.Text = "RS. 25000"
        '
        'VEHICLE_MAINTENANCE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 716)
        Me.Controls.Add(Me.TXT25000)
        Me.Controls.Add(Me.TXT15000)
        Me.Controls.Add(Me.TXT30000)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CHKCHANGE)
        Me.Controls.Add(Me.CHKREPAIR)
        Me.Controls.Add(Me.CHKREGULAR)
        Me.Controls.Add(Me.TXTTE)
        Me.Controls.Add(Me.LBLAMT)
        Me.Controls.Add(Me.CMBVREG)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.LBLVMAINTENANCE)
        Me.Controls.Add(Me.LBLVREGNO)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "VEHICLE_MAINTENANCE"
        Me.Text = "VEHICLE MAINTENANCE FORM"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents LBLAMT As System.Windows.Forms.Label
    Friend WithEvents CMBVREG As System.Windows.Forms.ComboBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents LBLVMAINTENANCE As System.Windows.Forms.Label
    Friend WithEvents TXTVNAME As System.Windows.Forms.TextBox
    Friend WithEvents LBLVREGNO As System.Windows.Forms.Label
    Friend WithEvents TXTVID As System.Windows.Forms.TextBox
    Friend WithEvents LBLFTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLVID As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TXTFTYPE As System.Windows.Forms.TextBox
    Friend WithEvents LBLVNAME As System.Windows.Forms.Label
    Friend WithEvents CHKREGULAR As System.Windows.Forms.CheckBox
    Friend WithEvents CHKREPAIR As System.Windows.Forms.CheckBox
    Friend WithEvents CHKCHANGE As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TXT30000 As System.Windows.Forms.TextBox
    Friend WithEvents TXT15000 As System.Windows.Forms.TextBox
    Friend WithEvents TXT25000 As System.Windows.Forms.TextBox
End Class
