﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DRIVER_REGISTERATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNSEARCH = New System.Windows.Forms.Button
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTID = New System.Windows.Forms.TextBox
        Me.LBLDID = New System.Windows.Forms.Label
        Me.LBLCREG = New System.Windows.Forms.Label
        Me.TXTMOB = New System.Windows.Forms.TextBox
        Me.TXTEMAIL = New System.Windows.Forms.TextBox
        Me.TXTPHNO = New System.Windows.Forms.TextBox
        Me.TXTADDR = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.LBLFEMALE = New System.Windows.Forms.RadioButton
        Me.LBLMALE = New System.Windows.Forms.RadioButton
        Me.LBLGENDER = New System.Windows.Forms.Label
        Me.LBLEMAIL = New System.Windows.Forms.Label
        Me.LBLDPHNO = New System.Windows.Forms.Label
        Me.LBLCMNO = New System.Windows.Forms.Label
        Me.LBLDADDR = New System.Windows.Forms.Label
        Me.LBLDNAME = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'BTNSEARCH
        '
        Me.BTNSEARCH.Location = New System.Drawing.Point(586, 448)
        Me.BTNSEARCH.Name = "BTNSEARCH"
        Me.BTNSEARCH.Size = New System.Drawing.Size(75, 23)
        Me.BTNSEARCH.TabIndex = 120
        Me.BTNSEARCH.Text = "SEARCH"
        Me.BTNSEARCH.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(746, 448)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 119
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(415, 448)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 118
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(241, 448)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 117
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(60, 448)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 116
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTID
        '
        Me.TXTID.Location = New System.Drawing.Point(178, 96)
        Me.TXTID.Name = "TXTID"
        Me.TXTID.Size = New System.Drawing.Size(219, 20)
        Me.TXTID.TabIndex = 115
        '
        'LBLDID
        '
        Me.LBLDID.AutoSize = True
        Me.LBLDID.Location = New System.Drawing.Point(46, 103)
        Me.LBLDID.Name = "LBLDID"
        Me.LBLDID.Size = New System.Drawing.Size(62, 13)
        Me.LBLDID.TabIndex = 114
        Me.LBLDID.Text = "DRIVER ID"
        '
        'LBLCREG
        '
        Me.LBLCREG.AutoSize = True
        Me.LBLCREG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLCREG.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLCREG.Location = New System.Drawing.Point(178, 13)
        Me.LBLCREG.Name = "LBLCREG"
        Me.LBLCREG.Size = New System.Drawing.Size(551, 56)
        Me.LBLCREG.TabIndex = 113
        Me.LBLCREG.Text = "DRIVER REGISTRATION"
        '
        'TXTMOB
        '
        Me.TXTMOB.Location = New System.Drawing.Point(178, 283)
        Me.TXTMOB.Name = "TXTMOB"
        Me.TXTMOB.Size = New System.Drawing.Size(219, 20)
        Me.TXTMOB.TabIndex = 112
        '
        'TXTEMAIL
        '
        Me.TXTEMAIL.Location = New System.Drawing.Point(178, 344)
        Me.TXTEMAIL.Name = "TXTEMAIL"
        Me.TXTEMAIL.Size = New System.Drawing.Size(219, 20)
        Me.TXTEMAIL.TabIndex = 111
        '
        'TXTPHNO
        '
        Me.TXTPHNO.Location = New System.Drawing.Point(629, 283)
        Me.TXTPHNO.Name = "TXTPHNO"
        Me.TXTPHNO.Size = New System.Drawing.Size(219, 20)
        Me.TXTPHNO.TabIndex = 110
        '
        'TXTADDR
        '
        Me.TXTADDR.Location = New System.Drawing.Point(178, 191)
        Me.TXTADDR.Multiline = True
        Me.TXTADDR.Name = "TXTADDR"
        Me.TXTADDR.Size = New System.Drawing.Size(219, 70)
        Me.TXTADDR.TabIndex = 109
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(178, 148)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(219, 20)
        Me.TextBox1.TabIndex = 108
        '
        'LBLFEMALE
        '
        Me.LBLFEMALE.AutoSize = True
        Me.LBLFEMALE.Location = New System.Drawing.Point(330, 402)
        Me.LBLFEMALE.Name = "LBLFEMALE"
        Me.LBLFEMALE.Size = New System.Drawing.Size(67, 17)
        Me.LBLFEMALE.TabIndex = 107
        Me.LBLFEMALE.TabStop = True
        Me.LBLFEMALE.Text = "FEMALE"
        Me.LBLFEMALE.UseVisualStyleBackColor = True
        '
        'LBLMALE
        '
        Me.LBLMALE.AutoSize = True
        Me.LBLMALE.Location = New System.Drawing.Point(178, 402)
        Me.LBLMALE.Name = "LBLMALE"
        Me.LBLMALE.Size = New System.Drawing.Size(54, 17)
        Me.LBLMALE.TabIndex = 106
        Me.LBLMALE.TabStop = True
        Me.LBLMALE.Text = "MALE"
        Me.LBLMALE.UseVisualStyleBackColor = True
        '
        'LBLGENDER
        '
        Me.LBLGENDER.AutoSize = True
        Me.LBLGENDER.Location = New System.Drawing.Point(46, 406)
        Me.LBLGENDER.Name = "LBLGENDER"
        Me.LBLGENDER.Size = New System.Drawing.Size(53, 13)
        Me.LBLGENDER.TabIndex = 105
        Me.LBLGENDER.Text = "GENDER"
        '
        'LBLEMAIL
        '
        Me.LBLEMAIL.AutoSize = True
        Me.LBLEMAIL.Location = New System.Drawing.Point(43, 351)
        Me.LBLEMAIL.Name = "LBLEMAIL"
        Me.LBLEMAIL.Size = New System.Drawing.Size(53, 13)
        Me.LBLEMAIL.TabIndex = 104
        Me.LBLEMAIL.Text = "EMAIL ID"
        '
        'LBLDPHNO
        '
        Me.LBLDPHNO.AutoSize = True
        Me.LBLDPHNO.Location = New System.Drawing.Point(475, 290)
        Me.LBLDPHNO.Name = "LBLDPHNO"
        Me.LBLDPHNO.Size = New System.Drawing.Size(121, 13)
        Me.LBLDPHNO.TabIndex = 103
        Me.LBLDPHNO.Text = "ALTERNATE NUMBER"
        '
        'LBLCMNO
        '
        Me.LBLCMNO.AutoSize = True
        Me.LBLCMNO.Location = New System.Drawing.Point(43, 290)
        Me.LBLCMNO.Name = "LBLCMNO"
        Me.LBLCMNO.Size = New System.Drawing.Size(97, 13)
        Me.LBLCMNO.TabIndex = 102
        Me.LBLCMNO.Text = "MOBILE NUMBER"
        '
        'LBLDADDR
        '
        Me.LBLDADDR.AutoSize = True
        Me.LBLDADDR.Location = New System.Drawing.Point(46, 209)
        Me.LBLDADDR.Name = "LBLDADDR"
        Me.LBLDADDR.Size = New System.Drawing.Size(59, 13)
        Me.LBLDADDR.TabIndex = 101
        Me.LBLDADDR.Text = "ADDRESS"
        '
        'LBLDNAME
        '
        Me.LBLDNAME.AutoSize = True
        Me.LBLDNAME.Location = New System.Drawing.Point(46, 155)
        Me.LBLDNAME.Name = "LBLDNAME"
        Me.LBLDNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLDNAME.TabIndex = 100
        Me.LBLDNAME.Text = "NAME"
        '
        'DRIVER_REGISTERATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 485)
        Me.Controls.Add(Me.BTNSEARCH)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.TXTID)
        Me.Controls.Add(Me.LBLDID)
        Me.Controls.Add(Me.LBLCREG)
        Me.Controls.Add(Me.TXTMOB)
        Me.Controls.Add(Me.TXTEMAIL)
        Me.Controls.Add(Me.TXTPHNO)
        Me.Controls.Add(Me.TXTADDR)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LBLFEMALE)
        Me.Controls.Add(Me.LBLMALE)
        Me.Controls.Add(Me.LBLGENDER)
        Me.Controls.Add(Me.LBLEMAIL)
        Me.Controls.Add(Me.LBLDPHNO)
        Me.Controls.Add(Me.LBLCMNO)
        Me.Controls.Add(Me.LBLDADDR)
        Me.Controls.Add(Me.LBLDNAME)
        Me.Name = "DRIVER_REGISTERATION"
        Me.Text = "DRIVER REGISTERATION FORM"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTNSEARCH As System.Windows.Forms.Button
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTID As System.Windows.Forms.TextBox
    Friend WithEvents LBLDID As System.Windows.Forms.Label
    Friend WithEvents LBLCREG As System.Windows.Forms.Label
    Friend WithEvents TXTMOB As System.Windows.Forms.TextBox
    Friend WithEvents TXTEMAIL As System.Windows.Forms.TextBox
    Friend WithEvents TXTPHNO As System.Windows.Forms.TextBox
    Friend WithEvents TXTADDR As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents LBLFEMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLMALE As System.Windows.Forms.RadioButton
    Friend WithEvents LBLGENDER As System.Windows.Forms.Label
    Friend WithEvents LBLEMAIL As System.Windows.Forms.Label
    Friend WithEvents LBLDPHNO As System.Windows.Forms.Label
    Friend WithEvents LBLCMNO As System.Windows.Forms.Label
    Friend WithEvents LBLDADDR As System.Windows.Forms.Label
    Friend WithEvents LBLDNAME As System.Windows.Forms.Label
End Class
