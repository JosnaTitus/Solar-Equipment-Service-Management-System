﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SUPPLIER_ORDER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CMBMTYPE = New System.Windows.Forms.ComboBox
        Me.LBLSORDER = New System.Windows.Forms.Label
        Me.CMBPTYPE = New System.Windows.Forms.ComboBox
        Me.TXTRATE = New System.Windows.Forms.TextBox
        Me.LBLBALANCE = New System.Windows.Forms.Label
        Me.TXTQTY = New System.Windows.Forms.TextBox
        Me.LBLADV = New System.Windows.Forms.Label
        Me.LBLTE = New System.Windows.Forms.Label
        Me.LBLRATE = New System.Windows.Forms.Label
        Me.LBLPTYPE = New System.Windows.Forms.Label
        Me.LBLMTYPE = New System.Windows.Forms.Label
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.TXTBALANCE = New System.Windows.Forms.TextBox
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.LBLQTY = New System.Windows.Forms.Label
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.TXTSID = New System.Windows.Forms.TextBox
        Me.LBLSNAME = New System.Windows.Forms.Label
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.TXTADV = New System.Windows.Forms.TextBox
        Me.CMBSNAME = New System.Windows.Forms.ComboBox
        Me.TXTOID = New System.Windows.Forms.TextBox
        Me.LBLSID = New System.Windows.Forms.Label
        Me.GRPTOTAL = New System.Windows.Forms.GroupBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.GRPODETAILS = New System.Windows.Forms.GroupBox
        Me.BTNCALCULATE = New System.Windows.Forms.Button
        Me.LBLOID = New System.Windows.Forms.Label
        Me.TXTDATE = New System.Windows.Forms.TextBox
        Me.GRPSDETAIL = New System.Windows.Forms.GroupBox
        Me.GRPTOTAL.SuspendLayout()
        Me.GRPODETAILS.SuspendLayout()
        Me.GRPSDETAIL.SuspendLayout()
        Me.SuspendLayout()
        '
        'CMBMTYPE
        '
        Me.CMBMTYPE.FormattingEnabled = True
        Me.CMBMTYPE.Location = New System.Drawing.Point(171, 26)
        Me.CMBMTYPE.Name = "CMBMTYPE"
        Me.CMBMTYPE.Size = New System.Drawing.Size(121, 21)
        Me.CMBMTYPE.TabIndex = 126
        Me.CMBMTYPE.Text = "SELECT TYPE"
        '
        'LBLSORDER
        '
        Me.LBLSORDER.AutoSize = True
        Me.LBLSORDER.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLSORDER.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSORDER.Location = New System.Drawing.Point(116, 13)
        Me.LBLSORDER.Name = "LBLSORDER"
        Me.LBLSORDER.Size = New System.Drawing.Size(624, 56)
        Me.LBLSORDER.TabIndex = 125
        Me.LBLSORDER.Text = "SUPPLIER ORDER DETAILS"
        '
        'CMBPTYPE
        '
        Me.CMBPTYPE.FormattingEnabled = True
        Me.CMBPTYPE.Location = New System.Drawing.Point(171, 62)
        Me.CMBPTYPE.Name = "CMBPTYPE"
        Me.CMBPTYPE.Size = New System.Drawing.Size(121, 21)
        Me.CMBPTYPE.TabIndex = 127
        Me.CMBPTYPE.Text = "SELECT TYPE"
        '
        'TXTRATE
        '
        Me.TXTRATE.Location = New System.Drawing.Point(171, 98)
        Me.TXTRATE.Name = "TXTRATE"
        Me.TXTRATE.Size = New System.Drawing.Size(121, 20)
        Me.TXTRATE.TabIndex = 122
        '
        'LBLBALANCE
        '
        Me.LBLBALANCE.AutoSize = True
        Me.LBLBALANCE.Location = New System.Drawing.Point(8, 140)
        Me.LBLBALANCE.Name = "LBLBALANCE"
        Me.LBLBALANCE.Size = New System.Drawing.Size(56, 13)
        Me.LBLBALANCE.TabIndex = 5
        Me.LBLBALANCE.Text = "BALANCE"
        '
        'TXTQTY
        '
        Me.TXTQTY.Location = New System.Drawing.Point(171, 137)
        Me.TXTQTY.Name = "TXTQTY"
        Me.TXTQTY.Size = New System.Drawing.Size(121, 20)
        Me.TXTQTY.TabIndex = 125
        '
        'LBLADV
        '
        Me.LBLADV.AutoSize = True
        Me.LBLADV.Location = New System.Drawing.Point(8, 89)
        Me.LBLADV.Name = "LBLADV"
        Me.LBLADV.Size = New System.Drawing.Size(58, 13)
        Me.LBLADV.TabIndex = 4
        Me.LBLADV.Text = "ADVANCE"
        '
        'LBLTE
        '
        Me.LBLTE.AutoSize = True
        Me.LBLTE.Location = New System.Drawing.Point(6, 41)
        Me.LBLTE.Name = "LBLTE"
        Me.LBLTE.Size = New System.Drawing.Size(95, 13)
        Me.LBLTE.TabIndex = 3
        Me.LBLTE.Text = "TOTAL EXPENSE"
        '
        'LBLRATE
        '
        Me.LBLRATE.AutoSize = True
        Me.LBLRATE.Location = New System.Drawing.Point(15, 105)
        Me.LBLRATE.Name = "LBLRATE"
        Me.LBLRATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLRATE.TabIndex = 2
        Me.LBLRATE.Text = "RATE"
        '
        'LBLPTYPE
        '
        Me.LBLPTYPE.AutoSize = True
        Me.LBLPTYPE.Location = New System.Drawing.Point(15, 70)
        Me.LBLPTYPE.Name = "LBLPTYPE"
        Me.LBLPTYPE.Size = New System.Drawing.Size(91, 13)
        Me.LBLPTYPE.TabIndex = 1
        Me.LBLPTYPE.Text = "PRODUCT TYPE"
        '
        'LBLMTYPE
        '
        Me.LBLMTYPE.AutoSize = True
        Me.LBLMTYPE.Location = New System.Drawing.Point(15, 34)
        Me.LBLMTYPE.Name = "LBLMTYPE"
        Me.LBLMTYPE.Size = New System.Drawing.Size(92, 13)
        Me.LBLMTYPE.TabIndex = 0
        Me.LBLMTYPE.Text = "MATERIAL TYPE"
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(653, 509)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 133
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'TXTBALANCE
        '
        Me.TXTBALANCE.Location = New System.Drawing.Point(142, 133)
        Me.TXTBALANCE.Name = "TXTBALANCE"
        Me.TXTBALANCE.Size = New System.Drawing.Size(100, 20)
        Me.TXTBALANCE.TabIndex = 2
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(335, 509)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 131
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'LBLQTY
        '
        Me.LBLQTY.AutoSize = True
        Me.LBLQTY.Location = New System.Drawing.Point(15, 144)
        Me.LBLQTY.Name = "LBLQTY"
        Me.LBLQTY.Size = New System.Drawing.Size(62, 13)
        Me.LBLQTY.TabIndex = 121
        Me.LBLQTY.Text = "QUANTITY"
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(509, 509)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 132
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(154, 509)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 130
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'TXTSID
        '
        Me.TXTSID.Location = New System.Drawing.Point(529, 78)
        Me.TXTSID.Name = "TXTSID"
        Me.TXTSID.Size = New System.Drawing.Size(143, 20)
        Me.TXTSID.TabIndex = 114
        '
        'LBLSNAME
        '
        Me.LBLSNAME.AutoSize = True
        Me.LBLSNAME.Location = New System.Drawing.Point(20, 82)
        Me.LBLSNAME.Name = "LBLSNAME"
        Me.LBLSNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLSNAME.TabIndex = 112
        Me.LBLSNAME.Text = "NAME"
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(398, 28)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLDATE.TabIndex = 111
        Me.LBLDATE.Text = "DATE"
        '
        'TXTADV
        '
        Me.TXTADV.Location = New System.Drawing.Point(142, 82)
        Me.TXTADV.Name = "TXTADV"
        Me.TXTADV.Size = New System.Drawing.Size(100, 20)
        Me.TXTADV.TabIndex = 1
        '
        'CMBSNAME
        '
        Me.CMBSNAME.FormattingEnabled = True
        Me.CMBSNAME.Location = New System.Drawing.Point(177, 82)
        Me.CMBSNAME.Name = "CMBSNAME"
        Me.CMBSNAME.Size = New System.Drawing.Size(163, 21)
        Me.CMBSNAME.TabIndex = 115
        Me.CMBSNAME.Text = "SELECT SUPPLIER NAME"
        '
        'TXTOID
        '
        Me.TXTOID.Location = New System.Drawing.Point(177, 25)
        Me.TXTOID.Name = "TXTOID"
        Me.TXTOID.Size = New System.Drawing.Size(163, 20)
        Me.TXTOID.TabIndex = 113
        '
        'LBLSID
        '
        Me.LBLSID.AutoSize = True
        Me.LBLSID.Location = New System.Drawing.Point(398, 85)
        Me.LBLSID.Name = "LBLSID"
        Me.LBLSID.Size = New System.Drawing.Size(74, 13)
        Me.LBLSID.TabIndex = 110
        Me.LBLSID.Text = "SUPPLIER ID"
        '
        'GRPTOTAL
        '
        Me.GRPTOTAL.Controls.Add(Me.LBLBALANCE)
        Me.GRPTOTAL.Controls.Add(Me.LBLADV)
        Me.GRPTOTAL.Controls.Add(Me.LBLTE)
        Me.GRPTOTAL.Controls.Add(Me.TXTBALANCE)
        Me.GRPTOTAL.Controls.Add(Me.TXTADV)
        Me.GRPTOTAL.Controls.Add(Me.TXTTE)
        Me.GRPTOTAL.Location = New System.Drawing.Point(463, 264)
        Me.GRPTOTAL.Name = "GRPTOTAL"
        Me.GRPTOTAL.Size = New System.Drawing.Size(333, 220)
        Me.GRPTOTAL.TabIndex = 129
        Me.GRPTOTAL.TabStop = False
        Me.GRPTOTAL.Text = "TOTAL"
        '
        'TXTTE
        '
        Me.TXTTE.Location = New System.Drawing.Point(142, 34)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(100, 20)
        Me.TXTTE.TabIndex = 0
        '
        'GRPODETAILS
        '
        Me.GRPODETAILS.Controls.Add(Me.BTNCALCULATE)
        Me.GRPODETAILS.Controls.Add(Me.CMBPTYPE)
        Me.GRPODETAILS.Controls.Add(Me.CMBMTYPE)
        Me.GRPODETAILS.Controls.Add(Me.TXTQTY)
        Me.GRPODETAILS.Controls.Add(Me.TXTRATE)
        Me.GRPODETAILS.Controls.Add(Me.LBLQTY)
        Me.GRPODETAILS.Controls.Add(Me.LBLRATE)
        Me.GRPODETAILS.Controls.Add(Me.LBLPTYPE)
        Me.GRPODETAILS.Controls.Add(Me.LBLMTYPE)
        Me.GRPODETAILS.Location = New System.Drawing.Point(99, 264)
        Me.GRPODETAILS.Name = "GRPODETAILS"
        Me.GRPODETAILS.Size = New System.Drawing.Size(333, 220)
        Me.GRPODETAILS.TabIndex = 128
        Me.GRPODETAILS.TabStop = False
        Me.GRPODETAILS.Text = "ORDER DETAILS"
        '
        'BTNCALCULATE
        '
        Me.BTNCALCULATE.Location = New System.Drawing.Point(80, 178)
        Me.BTNCALCULATE.Name = "BTNCALCULATE"
        Me.BTNCALCULATE.Size = New System.Drawing.Size(124, 24)
        Me.BTNCALCULATE.TabIndex = 128
        Me.BTNCALCULATE.Text = "CALCULATE"
        Me.BTNCALCULATE.UseVisualStyleBackColor = True
        '
        'LBLOID
        '
        Me.LBLOID.AutoSize = True
        Me.LBLOID.Location = New System.Drawing.Point(20, 25)
        Me.LBLOID.Name = "LBLOID"
        Me.LBLOID.Size = New System.Drawing.Size(60, 13)
        Me.LBLOID.TabIndex = 109
        Me.LBLOID.Text = "ORDER ID"
        '
        'TXTDATE
        '
        Me.TXTDATE.Location = New System.Drawing.Point(529, 22)
        Me.TXTDATE.Name = "TXTDATE"
        Me.TXTDATE.Size = New System.Drawing.Size(143, 20)
        Me.TXTDATE.TabIndex = 118
        '
        'GRPSDETAIL
        '
        Me.GRPSDETAIL.Controls.Add(Me.TXTDATE)
        Me.GRPSDETAIL.Controls.Add(Me.CMBSNAME)
        Me.GRPSDETAIL.Controls.Add(Me.TXTSID)
        Me.GRPSDETAIL.Controls.Add(Me.TXTOID)
        Me.GRPSDETAIL.Controls.Add(Me.LBLSNAME)
        Me.GRPSDETAIL.Controls.Add(Me.LBLDATE)
        Me.GRPSDETAIL.Controls.Add(Me.LBLSID)
        Me.GRPSDETAIL.Controls.Add(Me.LBLOID)
        Me.GRPSDETAIL.Location = New System.Drawing.Point(92, 105)
        Me.GRPSDETAIL.Name = "GRPSDETAIL"
        Me.GRPSDETAIL.Size = New System.Drawing.Size(704, 126)
        Me.GRPSDETAIL.TabIndex = 126
        Me.GRPSDETAIL.TabStop = False
        Me.GRPSDETAIL.Text = "SUPPLIER DETAILS"
        '
        'SUPPLIER_ORDER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(889, 614)
        Me.Controls.Add(Me.LBLSORDER)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.GRPTOTAL)
        Me.Controls.Add(Me.GRPODETAILS)
        Me.Controls.Add(Me.GRPSDETAIL)
        Me.Name = "SUPPLIER_ORDER"
        Me.Text = "SUPPLIER ORDER FORM"
        Me.GRPTOTAL.ResumeLayout(False)
        Me.GRPTOTAL.PerformLayout()
        Me.GRPODETAILS.ResumeLayout(False)
        Me.GRPODETAILS.PerformLayout()
        Me.GRPSDETAIL.ResumeLayout(False)
        Me.GRPSDETAIL.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CMBMTYPE As System.Windows.Forms.ComboBox
    Friend WithEvents LBLSORDER As System.Windows.Forms.Label
    Friend WithEvents CMBPTYPE As System.Windows.Forms.ComboBox
    Friend WithEvents TXTRATE As System.Windows.Forms.TextBox
    Friend WithEvents LBLBALANCE As System.Windows.Forms.Label
    Friend WithEvents TXTQTY As System.Windows.Forms.TextBox
    Friend WithEvents LBLADV As System.Windows.Forms.Label
    Friend WithEvents LBLTE As System.Windows.Forms.Label
    Friend WithEvents LBLRATE As System.Windows.Forms.Label
    Friend WithEvents LBLPTYPE As System.Windows.Forms.Label
    Friend WithEvents LBLMTYPE As System.Windows.Forms.Label
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents TXTBALANCE As System.Windows.Forms.TextBox
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents LBLQTY As System.Windows.Forms.Label
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents TXTSID As System.Windows.Forms.TextBox
    Friend WithEvents LBLSNAME As System.Windows.Forms.Label
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents TXTADV As System.Windows.Forms.TextBox
    Friend WithEvents CMBSNAME As System.Windows.Forms.ComboBox
    Friend WithEvents TXTOID As System.Windows.Forms.TextBox
    Friend WithEvents LBLSID As System.Windows.Forms.Label
    Friend WithEvents GRPTOTAL As System.Windows.Forms.GroupBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents GRPODETAILS As System.Windows.Forms.GroupBox
    Friend WithEvents BTNCALCULATE As System.Windows.Forms.Button
    Friend WithEvents LBLOID As System.Windows.Forms.Label
    Friend WithEvents TXTDATE As System.Windows.Forms.TextBox
    Friend WithEvents GRPSDETAIL As System.Windows.Forms.GroupBox
End Class
