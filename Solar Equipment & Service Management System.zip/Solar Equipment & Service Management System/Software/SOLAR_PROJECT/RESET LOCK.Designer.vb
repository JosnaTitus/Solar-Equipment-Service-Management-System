﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RESET_LOCK
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.CMBNAME = New System.Windows.Forms.ComboBox
        Me.LBLNAME = New System.Windows.Forms.Label
        Me.LBLLOGIN = New System.Windows.Forms.Label
        Me.LBLOLD = New System.Windows.Forms.Label
        Me.TXTOLD = New System.Windows.Forms.TextBox
        Me.LBLNEW = New System.Windows.Forms.Label
        Me.TXTNEW = New System.Windows.Forms.TextBox
        Me.LBLPASS = New System.Windows.Forms.Label
        Me.TXTPASS = New System.Windows.Forms.TextBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.LBLPASS)
        Me.Panel1.Controls.Add(Me.LBLNEW)
        Me.Panel1.Controls.Add(Me.TXTPASS)
        Me.Panel1.Controls.Add(Me.TXTNEW)
        Me.Panel1.Controls.Add(Me.LBLOLD)
        Me.Panel1.Controls.Add(Me.TXTOLD)
        Me.Panel1.Controls.Add(Me.CMBNAME)
        Me.Panel1.Controls.Add(Me.LBLNAME)
        Me.Panel1.Location = New System.Drawing.Point(231, 119)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(446, 206)
        Me.Panel1.TabIndex = 145
        '
        'CMBNAME
        '
        Me.CMBNAME.FormattingEnabled = True
        Me.CMBNAME.Location = New System.Drawing.Point(249, 21)
        Me.CMBNAME.Name = "CMBNAME"
        Me.CMBNAME.Size = New System.Drawing.Size(121, 21)
        Me.CMBNAME.TabIndex = 141
        Me.CMBNAME.Text = "SELECT NAME"
        '
        'LBLNAME
        '
        Me.LBLNAME.AutoSize = True
        Me.LBLNAME.Location = New System.Drawing.Point(52, 29)
        Me.LBLNAME.Name = "LBLNAME"
        Me.LBLNAME.Size = New System.Drawing.Size(71, 13)
        Me.LBLNAME.TabIndex = 139
        Me.LBLNAME.Text = "USER NAME"
        '
        'LBLLOGIN
        '
        Me.LBLLOGIN.AutoSize = True
        Me.LBLLOGIN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLLOGIN.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLLOGIN.Location = New System.Drawing.Point(231, 27)
        Me.LBLLOGIN.Name = "LBLLOGIN"
        Me.LBLLOGIN.Size = New System.Drawing.Size(446, 56)
        Me.LBLLOGIN.TabIndex = 144
        Me.LBLLOGIN.Text = "RESET LOCK FORM"
        '
        'LBLOLD
        '
        Me.LBLOLD.AutoSize = True
        Me.LBLOLD.Location = New System.Drawing.Point(52, 71)
        Me.LBLOLD.Name = "LBLOLD"
        Me.LBLOLD.Size = New System.Drawing.Size(95, 13)
        Me.LBLOLD.TabIndex = 143
        Me.LBLOLD.Text = "OLD PASSWORD"
        '
        'TXTOLD
        '
        Me.TXTOLD.Location = New System.Drawing.Point(248, 68)
        Me.TXTOLD.Name = "TXTOLD"
        Me.TXTOLD.Size = New System.Drawing.Size(121, 20)
        Me.TXTOLD.TabIndex = 142
        '
        'LBLNEW
        '
        Me.LBLNEW.AutoSize = True
        Me.LBLNEW.Location = New System.Drawing.Point(52, 112)
        Me.LBLNEW.Name = "LBLNEW"
        Me.LBLNEW.Size = New System.Drawing.Size(99, 13)
        Me.LBLNEW.TabIndex = 145
        Me.LBLNEW.Text = "NEW PASSWORD"
        '
        'TXTNEW
        '
        Me.TXTNEW.Location = New System.Drawing.Point(249, 112)
        Me.TXTNEW.Name = "TXTNEW"
        Me.TXTNEW.Size = New System.Drawing.Size(121, 20)
        Me.TXTNEW.TabIndex = 144
        '
        'LBLPASS
        '
        Me.LBLPASS.AutoSize = True
        Me.LBLPASS.Location = New System.Drawing.Point(52, 164)
        Me.LBLPASS.Name = "LBLPASS"
        Me.LBLPASS.Size = New System.Drawing.Size(122, 13)
        Me.LBLPASS.TabIndex = 147
        Me.LBLPASS.Text = "CONFIRM PASSWORD"
        '
        'TXTPASS
        '
        Me.TXTPASS.Location = New System.Drawing.Point(249, 157)
        Me.TXTPASS.Name = "TXTPASS"
        Me.TXTPASS.Size = New System.Drawing.Size(121, 20)
        Me.TXTPASS.TabIndex = 146
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(669, 358)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 194
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(525, 358)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 193
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(351, 358)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 192
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(170, 358)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 191
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'RESET_LOCK
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(890, 411)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LBLLOGIN)
        Me.Name = "RESET_LOCK"
        Me.Text = "RESET LOCK FORM"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CMBNAME As System.Windows.Forms.ComboBox
    Friend WithEvents LBLNAME As System.Windows.Forms.Label
    Friend WithEvents LBLLOGIN As System.Windows.Forms.Label
    Friend WithEvents LBLPASS As System.Windows.Forms.Label
    Friend WithEvents LBLNEW As System.Windows.Forms.Label
    Friend WithEvents TXTPASS As System.Windows.Forms.TextBox
    Friend WithEvents TXTNEW As System.Windows.Forms.TextBox
    Friend WithEvents LBLOLD As System.Windows.Forms.Label
    Friend WithEvents TXTOLD As System.Windows.Forms.TextBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
End Class
