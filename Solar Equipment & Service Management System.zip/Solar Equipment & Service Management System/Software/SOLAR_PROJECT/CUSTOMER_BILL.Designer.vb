﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER_BILL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LBLBILL = New System.Windows.Forms.Label
        Me.LBLINVOICE = New System.Windows.Forms.Label
        Me.GRPTOTAL = New System.Windows.Forms.GroupBox
        Me.TXTTE = New System.Windows.Forms.TextBox
        Me.TXTADV = New System.Windows.Forms.TextBox
        Me.TXTBAL = New System.Windows.Forms.TextBox
        Me.LBLADVANCE = New System.Windows.Forms.Label
        Me.LBLBALANCE = New System.Windows.Forms.Label
        Me.LBLTE = New System.Windows.Forms.Label
        Me.LBLTOTAL = New System.Windows.Forms.Label
        Me.TXTBTBP = New System.Windows.Forms.TextBox
        Me.GRPDETAIL = New System.Windows.Forms.GroupBox
        Me.TXTCID = New System.Windows.Forms.TextBox
        Me.TXTINVOICE = New System.Windows.Forms.TextBox
        Me.CMBNAME = New System.Windows.Forms.ComboBox
        Me.LBLCNAME = New System.Windows.Forms.Label
        Me.LBLCID = New System.Windows.Forms.Label
        Me.TXTDATE = New System.Windows.Forms.TextBox
        Me.BTNEXIT = New System.Windows.Forms.Button
        Me.BTNCLEAR = New System.Windows.Forms.Button
        Me.BTNSAVE = New System.Windows.Forms.Button
        Me.BTNADDNEW = New System.Windows.Forms.Button
        Me.LBLDATE = New System.Windows.Forms.Label
        Me.LBLBTBP = New System.Windows.Forms.Label
        Me.GRPDESC = New System.Windows.Forms.GroupBox
        Me.GRPTOTAL.SuspendLayout()
        Me.GRPDETAIL.SuspendLayout()
        Me.GRPDESC.SuspendLayout()
        Me.SuspendLayout()
        '
        'LBLBILL
        '
        Me.LBLBILL.AutoSize = True
        Me.LBLBILL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LBLBILL.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLBILL.Location = New System.Drawing.Point(303, 80)
        Me.LBLBILL.Name = "LBLBILL"
        Me.LBLBILL.Size = New System.Drawing.Size(338, 56)
        Me.LBLBILL.TabIndex = 118
        Me.LBLBILL.Text = "BILL DETAILS"
        '
        'LBLINVOICE
        '
        Me.LBLINVOICE.AutoSize = True
        Me.LBLINVOICE.Location = New System.Drawing.Point(15, 31)
        Me.LBLINVOICE.Name = "LBLINVOICE"
        Me.LBLINVOICE.Size = New System.Drawing.Size(69, 13)
        Me.LBLINVOICE.TabIndex = 0
        Me.LBLINVOICE.Text = "INVOICE NO"
        '
        'GRPTOTAL
        '
        Me.GRPTOTAL.Controls.Add(Me.TXTTE)
        Me.GRPTOTAL.Controls.Add(Me.TXTADV)
        Me.GRPTOTAL.Controls.Add(Me.TXTBAL)
        Me.GRPTOTAL.Controls.Add(Me.LBLADVANCE)
        Me.GRPTOTAL.Controls.Add(Me.LBLBALANCE)
        Me.GRPTOTAL.Controls.Add(Me.LBLTE)
        Me.GRPTOTAL.Controls.Add(Me.LBLTOTAL)
        Me.GRPTOTAL.Location = New System.Drawing.Point(102, 306)
        Me.GRPTOTAL.Name = "GRPTOTAL"
        Me.GRPTOTAL.Size = New System.Drawing.Size(312, 196)
        Me.GRPTOTAL.TabIndex = 120
        Me.GRPTOTAL.TabStop = False
        Me.GRPTOTAL.Text = "TOTAL"
        '
        'TXTTE
        '
        Me.TXTTE.Location = New System.Drawing.Point(156, 51)
        Me.TXTTE.Name = "TXTTE"
        Me.TXTTE.Size = New System.Drawing.Size(121, 20)
        Me.TXTTE.TabIndex = 17
        '
        'TXTADV
        '
        Me.TXTADV.Location = New System.Drawing.Point(156, 91)
        Me.TXTADV.Name = "TXTADV"
        Me.TXTADV.Size = New System.Drawing.Size(121, 20)
        Me.TXTADV.TabIndex = 16
        '
        'TXTBAL
        '
        Me.TXTBAL.Location = New System.Drawing.Point(156, 134)
        Me.TXTBAL.Name = "TXTBAL"
        Me.TXTBAL.Size = New System.Drawing.Size(121, 20)
        Me.TXTBAL.TabIndex = 15
        '
        'LBLADVANCE
        '
        Me.LBLADVANCE.AutoSize = True
        Me.LBLADVANCE.Location = New System.Drawing.Point(26, 91)
        Me.LBLADVANCE.Name = "LBLADVANCE"
        Me.LBLADVANCE.Size = New System.Drawing.Size(58, 13)
        Me.LBLADVANCE.TabIndex = 12
        Me.LBLADVANCE.Text = "ADVANCE"
        '
        'LBLBALANCE
        '
        Me.LBLBALANCE.AutoSize = True
        Me.LBLBALANCE.Location = New System.Drawing.Point(26, 134)
        Me.LBLBALANCE.Name = "LBLBALANCE"
        Me.LBLBALANCE.Size = New System.Drawing.Size(56, 13)
        Me.LBLBALANCE.TabIndex = 11
        Me.LBLBALANCE.Text = "BALANCE"
        '
        'LBLTE
        '
        Me.LBLTE.AutoSize = True
        Me.LBLTE.Location = New System.Drawing.Point(26, 51)
        Me.LBLTE.Name = "LBLTE"
        Me.LBLTE.Size = New System.Drawing.Size(95, 13)
        Me.LBLTE.TabIndex = 8
        Me.LBLTE.Text = "TOTAL EXPENSE"
        '
        'LBLTOTAL
        '
        Me.LBLTOTAL.AutoSize = True
        Me.LBLTOTAL.Location = New System.Drawing.Point(26, 15)
        Me.LBLTOTAL.Name = "LBLTOTAL"
        Me.LBLTOTAL.Size = New System.Drawing.Size(0, 13)
        Me.LBLTOTAL.TabIndex = 5
        '
        'TXTBTBP
        '
        Me.TXTBTBP.Location = New System.Drawing.Point(21, 58)
        Me.TXTBTBP.Name = "TXTBTBP"
        Me.TXTBTBP.Size = New System.Drawing.Size(100, 20)
        Me.TXTBTBP.TabIndex = 19
        '
        'GRPDETAIL
        '
        Me.GRPDETAIL.Controls.Add(Me.TXTCID)
        Me.GRPDETAIL.Controls.Add(Me.TXTINVOICE)
        Me.GRPDETAIL.Controls.Add(Me.CMBNAME)
        Me.GRPDETAIL.Controls.Add(Me.LBLCNAME)
        Me.GRPDETAIL.Controls.Add(Me.LBLCID)
        Me.GRPDETAIL.Controls.Add(Me.LBLINVOICE)
        Me.GRPDETAIL.Location = New System.Drawing.Point(113, 155)
        Me.GRPDETAIL.Name = "GRPDETAIL"
        Me.GRPDETAIL.Size = New System.Drawing.Size(656, 113)
        Me.GRPDETAIL.TabIndex = 119
        Me.GRPDETAIL.TabStop = False
        Me.GRPDETAIL.Text = "CUSTOMER DETAILS"
        '
        'TXTCID
        '
        Me.TXTCID.Location = New System.Drawing.Point(529, 79)
        Me.TXTCID.Name = "TXTCID"
        Me.TXTCID.Size = New System.Drawing.Size(100, 20)
        Me.TXTCID.TabIndex = 20
        '
        'TXTINVOICE
        '
        Me.TXTINVOICE.Location = New System.Drawing.Point(151, 24)
        Me.TXTINVOICE.Name = "TXTINVOICE"
        Me.TXTINVOICE.Size = New System.Drawing.Size(121, 20)
        Me.TXTINVOICE.TabIndex = 14
        '
        'CMBNAME
        '
        Me.CMBNAME.FormattingEnabled = True
        Me.CMBNAME.Location = New System.Drawing.Point(151, 79)
        Me.CMBNAME.Name = "CMBNAME"
        Me.CMBNAME.Size = New System.Drawing.Size(121, 21)
        Me.CMBNAME.TabIndex = 13
        '
        'LBLCNAME
        '
        Me.LBLCNAME.AutoSize = True
        Me.LBLCNAME.Location = New System.Drawing.Point(15, 79)
        Me.LBLCNAME.Name = "LBLCNAME"
        Me.LBLCNAME.Size = New System.Drawing.Size(38, 13)
        Me.LBLCNAME.TabIndex = 7
        Me.LBLCNAME.Text = "NAME"
        '
        'LBLCID
        '
        Me.LBLCID.AutoSize = True
        Me.LBLCID.Location = New System.Drawing.Point(362, 79)
        Me.LBLCID.Name = "LBLCID"
        Me.LBLCID.Size = New System.Drawing.Size(82, 13)
        Me.LBLCID.TabIndex = 6
        Me.LBLCID.Text = "CUSTOMER ID"
        '
        'TXTDATE
        '
        Me.TXTDATE.Location = New System.Drawing.Point(21, 144)
        Me.TXTDATE.Name = "TXTDATE"
        Me.TXTDATE.Size = New System.Drawing.Size(100, 20)
        Me.TXTDATE.TabIndex = 18
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(695, 514)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 23)
        Me.BTNEXIT.TabIndex = 117
        Me.BTNEXIT.Text = "EXIT"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Location = New System.Drawing.Point(551, 514)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 23)
        Me.BTNCLEAR.TabIndex = 116
        Me.BTNCLEAR.Text = "CLEAR"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Location = New System.Drawing.Point(377, 514)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(75, 23)
        Me.BTNSAVE.TabIndex = 115
        Me.BTNSAVE.Text = "SAVE"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'BTNADDNEW
        '
        Me.BTNADDNEW.Location = New System.Drawing.Point(196, 514)
        Me.BTNADDNEW.Name = "BTNADDNEW"
        Me.BTNADDNEW.Size = New System.Drawing.Size(75, 23)
        Me.BTNADDNEW.TabIndex = 114
        Me.BTNADDNEW.Text = "ADD NEW "
        Me.BTNADDNEW.UseVisualStyleBackColor = True
        '
        'LBLDATE
        '
        Me.LBLDATE.AutoSize = True
        Me.LBLDATE.Location = New System.Drawing.Point(18, 98)
        Me.LBLDATE.Name = "LBLDATE"
        Me.LBLDATE.Size = New System.Drawing.Size(36, 13)
        Me.LBLDATE.TabIndex = 10
        Me.LBLDATE.Text = "DATE"
        '
        'LBLBTBP
        '
        Me.LBLBTBP.AutoSize = True
        Me.LBLBTBP.Location = New System.Drawing.Point(18, 22)
        Me.LBLBTBP.Name = "LBLBTBP"
        Me.LBLBTBP.Size = New System.Drawing.Size(119, 13)
        Me.LBLBTBP.TabIndex = 9
        Me.LBLBTBP.Text = "BALANCE TO BE PAID"
        '
        'GRPDESC
        '
        Me.GRPDESC.Controls.Add(Me.TXTBTBP)
        Me.GRPDESC.Controls.Add(Me.TXTDATE)
        Me.GRPDESC.Controls.Add(Me.LBLDATE)
        Me.GRPDESC.Controls.Add(Me.LBLBTBP)
        Me.GRPDESC.Location = New System.Drawing.Point(457, 299)
        Me.GRPDESC.Name = "GRPDESC"
        Me.GRPDESC.Size = New System.Drawing.Size(336, 202)
        Me.GRPDESC.TabIndex = 121
        Me.GRPDESC.TabStop = False
        Me.GRPDESC.Text = "DESCRIPTION"
        '
        'CUSTOMER_BILL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 617)
        Me.Controls.Add(Me.LBLBILL)
        Me.Controls.Add(Me.GRPTOTAL)
        Me.Controls.Add(Me.GRPDETAIL)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNSAVE)
        Me.Controls.Add(Me.BTNADDNEW)
        Me.Controls.Add(Me.GRPDESC)
        Me.Name = "CUSTOMER_BILL"
        Me.Text = "CUSTOMER BILL FORM"
        Me.GRPTOTAL.ResumeLayout(False)
        Me.GRPTOTAL.PerformLayout()
        Me.GRPDETAIL.ResumeLayout(False)
        Me.GRPDETAIL.PerformLayout()
        Me.GRPDESC.ResumeLayout(False)
        Me.GRPDESC.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LBLBILL As System.Windows.Forms.Label
    Friend WithEvents LBLINVOICE As System.Windows.Forms.Label
    Friend WithEvents GRPTOTAL As System.Windows.Forms.GroupBox
    Friend WithEvents TXTTE As System.Windows.Forms.TextBox
    Friend WithEvents TXTADV As System.Windows.Forms.TextBox
    Friend WithEvents TXTBAL As System.Windows.Forms.TextBox
    Friend WithEvents LBLADVANCE As System.Windows.Forms.Label
    Friend WithEvents LBLBALANCE As System.Windows.Forms.Label
    Friend WithEvents LBLTE As System.Windows.Forms.Label
    Friend WithEvents LBLTOTAL As System.Windows.Forms.Label
    Friend WithEvents TXTBTBP As System.Windows.Forms.TextBox
    Friend WithEvents GRPDETAIL As System.Windows.Forms.GroupBox
    Friend WithEvents TXTCID As System.Windows.Forms.TextBox
    Friend WithEvents TXTINVOICE As System.Windows.Forms.TextBox
    Friend WithEvents CMBNAME As System.Windows.Forms.ComboBox
    Friend WithEvents LBLCNAME As System.Windows.Forms.Label
    Friend WithEvents LBLCID As System.Windows.Forms.Label
    Friend WithEvents TXTDATE As System.Windows.Forms.TextBox
    Friend WithEvents BTNEXIT As System.Windows.Forms.Button
    Friend WithEvents BTNCLEAR As System.Windows.Forms.Button
    Friend WithEvents BTNSAVE As System.Windows.Forms.Button
    Friend WithEvents BTNADDNEW As System.Windows.Forms.Button
    Friend WithEvents LBLDATE As System.Windows.Forms.Label
    Friend WithEvents LBLBTBP As System.Windows.Forms.Label
    Friend WithEvents GRPDESC As System.Windows.Forms.GroupBox
End Class
